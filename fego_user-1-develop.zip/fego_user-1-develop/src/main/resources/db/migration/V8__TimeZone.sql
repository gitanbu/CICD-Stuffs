alter table hdfc."user" add column time_zone character varying(255);
alter table iob."user" add column time_zone character varying(255);

alter table hdfc."user" add column is_batch_user boolean;
alter table iob."user" add column is_batch_user boolean;

INSERT INTO hdfc."user"(id,address_id,
  email_id, is_otp, mobile, first_name, is_deleted, tenant, onboard_status, created_at, updated_at, created_by, updated_by, forget_password_key, password, user_type, is_account_logged_in, is_batch_user)
	VALUES (100001,0,'batch-admin@fego.com', true, '1234567890', 'Batch User', false, 'hdfc', 'REGISTRATION_COMPLETED', '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0, null, '', 'customer', false, true);

INSERT INTO iob."user"(id,address_id,
	email_id, is_otp, mobile, first_name, is_deleted, tenant, onboard_status, created_at, updated_at, created_by, updated_by, forget_password_key, password, user_type, is_account_logged_in, is_batch_user)
	VALUES (100001,0,'batch-admin@fego.com', true, '1234567890', 'Batch User', false, 'iob', 'REGISTRATION_COMPLETED', '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0, null, '', 'customer', false, true);

INSERT INTO hdfc.user_role(
	id, role_id, user_id, is_deleted, created_at, updated_at, created_by, updated_by)
	VALUES (100001, 3, 100001, false, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0);
INSERT INTO iob.user_role(
	id, role_id, user_id, is_deleted, created_at, updated_at, created_by, updated_by)
	VALUES (100001, 3, 100001, false, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0);

update hdfc."user" set is_batch_user = false where id = 100000;
update iob."user" set is_batch_user = false where id = 100000;