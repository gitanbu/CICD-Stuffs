alter table iob."user" add column failure_attempts integer;
alter table iob."user" add column lock_time timestamp;
alter table iob."user" add column account_locked boolean;