alter table iob."user" add column password_changed_time timestamp;
alter table iob."user" add column old_password character varying(500);