create schema if not exists common;

CREATE TABLE common.tenant (
  id bigserial PRIMARY KEY,
  name varchar(512) NOT NULL,
  description varchar(512) NOT NULL,
  is_deleted boolean,
  created_at timestamp,
  updated_at timestamp,
  created_by bigint,
  updated_by bigint
);

INSERT INTO common.tenant
  VALUES (1, 'hdfc', 'HDFC Bank', FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
         (2, 'iob', 'Indian Overseas Bank', FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0);

CREATE TABLE common.widget (
  id bigserial PRIMARY KEY,
  tenant_id bigint,
  widget_name varchar(512) NOT NULL,
  is_present boolean,
  is_deleted boolean,
  created_at timestamp,
  updated_at timestamp,
  created_by bigint,
  updated_by bigint
);

INSERT INTO common.widget
  VALUES (1, 1, 'goals', FALSE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
  (2, 1, 'budget', TRUE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
  (3, 1, 'calendar', FALSE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
  (4, 1, 'score', TRUE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
  (5, 2, 'goals', FALSE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
  (6, 2, 'budget', TRUE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
  (7, 2, 'calendar', FALSE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0),
  (8, 2, 'score', TRUE, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0);