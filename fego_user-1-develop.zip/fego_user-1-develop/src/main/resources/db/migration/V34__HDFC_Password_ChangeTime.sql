alter table hdfc."user" add column password_changed_time timestamp;
alter table hdfc."user" add column old_password character varying(500);