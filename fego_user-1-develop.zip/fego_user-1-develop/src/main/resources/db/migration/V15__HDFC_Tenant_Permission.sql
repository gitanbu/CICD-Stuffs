INSERT INTO hdfc.role_permission
  VALUES (160, 2, 47, FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0);