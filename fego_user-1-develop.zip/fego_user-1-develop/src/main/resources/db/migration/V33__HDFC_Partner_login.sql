alter table hdfc."user" add column failure_attempts integer;
alter table hdfc."user" add column lock_time timestamp;
alter table hdfc."user" add column account_locked boolean;