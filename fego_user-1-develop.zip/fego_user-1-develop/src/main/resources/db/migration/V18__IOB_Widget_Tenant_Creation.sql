CREATE TABLE iob.widget (
  id bigserial PRIMARY KEY,
  widget_name varchar(512) NOT NULL,
  is_subscribed boolean,
  description character varying(255),
  type character varying(255),
  is_deleted boolean,
  created_at timestamp,
  updated_at timestamp,
  created_by bigint,
  updated_by bigint
);

INSERT INTO iob.widget
  VALUES (1, 'EXPENDITURE', FALSE, 'Expenditure Report', 'customer', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (2, 'GOAL', TRUE, 'Saving Goals', 'customer', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (3, 'FINANCIAL_HEALTH', FALSE, 'Financial Health Score', 'customer',FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (4, 'BUDGET', TRUE, 'Budget Tracker', 'customer', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (5, 'PEER_RANK', TRUE, 'Peer Group Insights', 'customer', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (6, 'CALENDAR', TRUE, 'Financial Calendar', 'customer',FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (7, 'KYC', TRUE, 'Account Information & Kyc', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (8, 'LENDING', TRUE, 'Lending', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (9, 'LIQUIDITY_ANALYSIS', TRUE, 'Liquidity, Solvency & Risk', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (10, 'COLLECTIONS', TRUE, 'User Monitoring and Collections/Recoverability', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (11, 'FRAUD', TRUE, 'Fraud - Transactions & Users', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (12, 'INCOME', TRUE, 'Income - Detection and Estimation', 'partner',FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (13, 'CUSTOMER_360', TRUE, 'Customer 360', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (14, 'WEALTH', FALSE, 'Wealth', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0),
  (15, 'PARTNER_360', FALSE, 'Partner 360', 'partner', FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0);


CREATE TABLE iob.tenant (
  id bigserial PRIMARY KEY,
  name varchar(512) NOT NULL,
  description varchar(512) NOT NULL,
  address character varying(255),
  type character varying(255),
  account_aggregator character varying(255),
  is_onboarding_subscribed boolean,
  is_data_categorization_subscribed boolean,
  is_deleted boolean,
  created_at timestamp,
  updated_at timestamp,
  created_by bigint,
  updated_by bigint
);

INSERT INTO iob.tenant
  VALUES (1, 'iob', 'Indian Overseas Bank', 'ACROPOLIS, 9th Floor, New Door No.148 (Old No.68), Dr. Radhakrishnan Salai, Mylapore, Chennai – 600 004', 'Scheduled commercial bank', 'OneMoney', TRUE, FALSE, FALSE, '2021-07-01 00:00:00', '2021-07-01 00:00:00', 0, 0);

INSERT INTO iob.permission
    VALUES (81, 'CATEGORIZATION_PERCENTAGE_PRIVILEGE', FALSE, '2021-07-24 00:00:00', '2021-06-24 00:00:00', 0, 0);
INSERT INTO iob.role_permission
    VALUES (161, 2, 81, FALSE, '2021-06-24 00:00:00', '2021-06-24 00:00:00', 0, 0),
    (162, 3, 81, FALSE, '2021-06-24 00:00:00', '2021-06-24 00:00:00', 0, 0);