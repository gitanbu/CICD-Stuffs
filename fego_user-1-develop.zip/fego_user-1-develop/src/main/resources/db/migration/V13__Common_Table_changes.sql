alter table common.tenant add column address character varying(255);
alter table common.tenant add column type character varying(255);

ALTER TABLE common.widget RENAME column is_present TO is_subscribed;
alter table common.widget add column description character varying(255);
alter table common.widget add column type character varying(255);

delete from common.widget;
delete from common.tenant;

INSERT INTO common.tenant
  VALUES (1, 'hdfc', 'HDFC Bank', FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0, 'ACROPOLIS, 9th Floor, New Door No.148 (Old No.68), Dr. Radhakrishnan Salai, Mylapore, Chennai – 600 004', 'Scheduled commercial bank'),
         (2, 'iob', 'Indian Overseas Bank', FALSE, '2021-03-19 00:00:00', '2021-03-19 00:00:00', 0, 0, 'ACROPOLIS, 9th Floor, New Door No.148 (Old No.68), Dr. Radhakrishnan Salai, Mylapore, Chennai – 600 004', 'Scheduled commercial bank');

INSERT INTO common.widget
  VALUES (1, 1, 'EXPENDITURE', FALSE,FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Expenditure Report', 'customer'),
  (2, 1, 'GOAL', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Goals', 'customer'),
  (3, 1, 'FINANCIAL_HEALTH', FALSE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Financial Health', 'customer'),
  (4, 1, 'BUDGET', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Budget', 'customer'),
  (5, 1, 'PEER_RANK', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Peer Rank', 'customer'),
  (6, 1, 'CALENDAR', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Financial Calendar', 'customer'),
  (7, 1, 'COLLECTIONS', TRUE,FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Collections', 'partner'),
  (8, 1, 'WEALTH', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Wealth', 'partner'),
  (9, 1, 'LOAN_MONITORING', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Loan Monitoring', 'partner'),
  (10, 1, 'LIQUIDITY_ANALYSIS', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Liquidity Analysis', 'partner'),
  (11, 1, 'PARTNER_360', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Partner 360', 'partner'),
  (12, 1, 'CUSTOMER_360', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Customer 360', 'partner'),
  (13, 2, 'EXPENDITURE', FALSE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Expenditure Report', 'customer'),
  (14, 2, 'GOAL', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Goals', 'customer'),
  (15, 2, 'FINANCIAL_HEALTH', FALSE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Financial Health', 'customer'),
  (16, 2, 'BUDGET', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Budget', 'customer'),
  (17, 2, 'PEER_RANK',TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Peer Rank', 'customer'),
  (18, 2, 'CALENDAR', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Financial Calendar', 'customer'),
  (19, 2, 'COLLECTIONS',TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Collections', 'partner'),
  (20, 2, 'WEALTH', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Wealth', 'partner'),
  (21, 2, 'LOAN_MONITORING',TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Loan Monitoring', 'partner'),
  (22, 2, 'LIQUIDITY_ANALYSIS', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Liquidity Analysis', 'partner'),
  (23, 2, 'PARTNER_360', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Partner 360', 'partner'),
  (24, 2, 'CUSTOMER_360', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Customer 360', 'partner');