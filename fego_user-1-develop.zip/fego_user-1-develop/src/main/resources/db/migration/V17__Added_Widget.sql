INSERT INTO common.widget
  VALUES
  (29, 1, 'CUSTOMER_360', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Customer 360', 'partner'),
  (30, 2, 'CUSTOMER_360', TRUE, FALSE, '2021-06-28 00:00:00', '2021-06-28 00:00:00', 0, 0, 'Customer 360', 'partner');