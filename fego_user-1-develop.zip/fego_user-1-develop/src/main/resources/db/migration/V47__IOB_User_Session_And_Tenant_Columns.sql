CREATE TABLE iob.user_session (
  id bigserial PRIMARY KEY,
  user_id bigint,
  access_date date,
  start_time timestamp,
  end_time timestamp,
  duration bigint,
  channel character varying(512),
  is_deleted boolean,
  created_at timestamp,
  updated_at timestamp,
  created_by bigint,
  updated_by bigint
);

alter table iob.tenant add column is_account_aggregator_subscribed boolean;
update iob.tenant set is_account_aggregator_subscribed = true;

INSERT INTO iob.permission
    VALUES (210, 'ACCOUNT_AGGREGATOR_UPDATE_PRIVILEGE', FALSE, '2021-07-09 00:00:00', '2021-06-24 00:00:00', 0, 0),
           (211, 'CUSTOMER_AUDIT_WRITE_PRIVILEGE', FALSE, '2021-07-09 00:00:00', '2021-06-24 00:00:00', 0, 0),
           (212, 'FINANCIAL_LADDER_GRID_DETAILS_EXPORT_PRIVILEGE', FALSE, '2021-07-09 00:00:00', '2021-06-24 00:00:00', 0, 0),
           (213, 'FINANCIAL_LADDER_GRID_DETAILS_READ_PRIVILEGE', FALSE, '2021-07-09 00:00:00', '2021-06-24 00:00:00', 0, 0);

INSERT INTO iob.role_permission
  VALUES (417, 2, 210, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (418, 3, 210, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (419, 2, 211, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (420, 3, 211, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (421, 2, 182, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (422, 2, 212, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (423, 3, 212, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (424, 2, 213, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0),
         (425, 3, 213, FALSE, '2021-07-09 00:00:00', '2021-07-09 00:00:00', 0, 0);

CREATE TABLE iob.session_audit (
  id bigserial PRIMARY KEY,
  user_id bigint,
  uri character varying(512),
  type character varying(512),
  action character varying(512),
  ip_address character varying(512),
  is_deleted boolean,
  created_at timestamp,
  updated_at timestamp,
  created_by bigint,
  updated_by bigint
);