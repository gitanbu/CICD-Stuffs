package com.fego.userservice.dto.application;

/**
 * <p>
 * Generic message response.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public class GenericResponseDto {
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}