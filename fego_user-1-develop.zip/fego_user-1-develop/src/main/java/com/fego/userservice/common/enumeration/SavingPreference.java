package com.fego.userservice.common.enumeration;

import org.springframework.lang.Nullable;

import java.util.Objects;

/**
 * <p>
 * Enum of Saving Preference of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public enum SavingPreference {
    NEVER_SAVED(0),
    ONCE_IN_WHILE(1),
    AGGRESSIVE_SAVER(2);

    private final int code;

    SavingPreference(int code) {
        this.code = code;
    }

    public static SavingPreference valueOf(int code) {
        var savingPreference = resolve(code);
        if (Objects.isNull(savingPreference)) {
            throw new IllegalArgumentException("No matching constant found for [" + code + "]");
        }
        return savingPreference;
    }

    @Nullable
    public static SavingPreference resolve(int code) {
        for (SavingPreference savingPreference : values()) {
            if (savingPreference.code() == code) {
                return savingPreference;
            }
        }
        return null;
    }

    public int code() {
        return this.code;
    }
}