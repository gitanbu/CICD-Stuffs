package com.fego.userservice.common.base;

import com.fego.foundation.common.config.ResponseMessage;
import com.fego.foundation.common.enumeration.ErrorCode;
import com.fego.foundation.exception.RecordNotFoundException;
import com.fego.userservice.common.base.specification.IdSpecifications;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * <p>
 * Base service which application service extends.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public abstract class BaseService<M extends BaseModel, D extends BaseDto, T extends BaseTask> {

    public static final String PARTNER = "partner";
    public static final String CUSTOMER = "customer";
    BaseRepository<M> baseRepository;
    IdSpecifications<M> idSpecifications;
    BaseMapper<M, D> baseMapper;
    BaseTask<M> baseTask;
    Class<M> modelType;
    @Autowired
    private ResponseMessage responseMessage;

    protected BaseService(BaseRepository<M> baseRepository, BaseMapper<M, D> baseMapper,
                          IdSpecifications<M> idSpecifications, BaseTask<M> baseTask) {
        this.baseRepository = baseRepository;
        this.idSpecifications = idSpecifications;
        this.baseMapper = baseMapper;
        this.baseTask = baseTask;
        this.modelType = (Class<M>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    public void validateAdd(D incomingDto) {
    }

    public final D add(D incomingDto) {
        validateAdd(incomingDto);
        var incomingModel = baseMapper.dtoToDomain(incomingDto);
        var savedModel = addModel(incomingModel);
        return baseMapper.domainToDto(savedModel);
    }

    public final M addModel(M incomingModel) {
        var savedModel = baseRepository.save(incomingModel);
        baseTask.onCreate(savedModel);
        return savedModel;
    }

    /**
     * The extending services shall implement their logic to patch the
     * `toUpdateModel` with the `incomingModel`
     * <p>
     * This method should be abstract in which case all extending service classes
     * must provide an implementation.
     *
     * @param incomingModel - Model with updated values.
     * @param toUpdateModel - Model returned by Database which needs to be updated.
     */
    public void doPatch(M incomingModel, M toUpdateModel) {
        throw new ResponseStatusException(HttpStatus.NOT_IMPLEMENTED);
    }

    public void validatePatch(D incomingDto) {
    }

    public void patch(D incomingDto) {
        Optional<M> toUpdate = baseRepository.findOne(idSpecifications.findById(incomingDto.getId()));
        if (toUpdate.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND, responseMessage.getErrorMessage(ErrorCode.RECORD_NOT_FOUND));
        }
        validatePatch(incomingDto);
        var incomingModel = baseMapper.dtoToDomain(incomingDto);
        var toUpdateModel = toUpdate.get();
        patchModel(incomingModel, toUpdateModel);
    }

    public void patchModel(M incomingModel, M toUpdateModel) {
        doPatch(incomingModel, toUpdateModel);
        baseRepository.saveAndFlush(toUpdateModel);
    }

    public D findById(Long id) {
        Optional<M> fegoEntity = findModelById(id);
        if (fegoEntity.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND,
                    responseMessage.getErrorMessage(ErrorCode.RECORD_NOT_FOUND,
                            String.format("There is no %s with id %d", modelType.getSimpleName(), id)));
        }
        return baseMapper.domainToDto(fegoEntity.get());
    }

    public D findOne(Specification<M> specs) {
        Optional<M> fegoEntity = findOneModel(specs);
        if (fegoEntity.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND, responseMessage.getErrorMessage(ErrorCode.RECORD_NOT_FOUND));
        }
        return baseMapper.domainToDto(fegoEntity.get());
    }

    public Optional<M> findOneModel(Specification<M> specs) {
        return baseRepository.findOne(specs);
    }

    public D findByMobile(String searchValue) {
        Specification<M> baseSpecification = idSpecifications.findByMobileNumber(searchValue);
        Optional<M> fegoEntity = baseRepository.findOne(baseSpecification);
        if (fegoEntity.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND,
                    responseMessage.getErrorMessage(ErrorCode.RECORD_NOT_FOUND,
                            String.format("There is no %s with %s %s", modelType.getSimpleName(), "mobile", searchValue)));
        }
        return baseMapper.domainToDto(fegoEntity.get());
    }

    public Optional<M> userExists(String searchValue, String type) {
        Specification<M> baseSpecification = type.equals(PARTNER) ? idSpecifications.findByEmail(searchValue) : idSpecifications.findByMobileNumber(searchValue);
        return baseRepository.findOne(baseSpecification);
    }

    public Optional<M> findModelById(Long id) {
        return baseRepository.findById(id);
    }

    public D findByTenantName(String tenantId) {
        Specification<M> baseSpecification = idSpecifications.findByTenantName(tenantId);
        Optional<M> fegoEntity = baseRepository.findOne(baseSpecification);
        if (fegoEntity.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND,
                    responseMessage.getErrorMessage(ErrorCode.RECORD_NOT_FOUND,
                            String.format(". There is no %s with %s", modelType.getSimpleName(), tenantId)));
        }
        return baseMapper.domainToDto(fegoEntity.get());
    }

    public List<D> findAll() {
        Specification<M> mSpecification = idSpecifications.notDeleted();
        List<M> models = findAllModels(mSpecification);
        return models.stream().map(m -> baseMapper.domainToDto(m)).collect(Collectors.toList());
    }

    public List<D> findAll(Specification<M> specifications) {
        List<M> models = findAllModels(specifications.and(idSpecifications.notDeleted()));
        return models.stream().map(m -> baseMapper.domainToDto(m)).collect(Collectors.toList());
    }

    public List<D> findAllRecords() {
        List<M> models = baseRepository.findAll();
        return models.stream().map(m -> baseMapper.domainToDto(m)).collect(Collectors.toList());
    }

    public List<M> findAllModels(Specification<M> specifications) {
        return baseRepository.findAll(specifications);
    }

    public Optional<D> findOneOrReturnEmpty(Specification<M> specs) {
        Optional<M> fegoEntity = findOneModel(specs);
        if (fegoEntity.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(baseMapper.domainToDto(fegoEntity.get()));
    }
}
