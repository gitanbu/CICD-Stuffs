package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.entity.RolePermission;

/**
 * <p>
 * Repository for RolePermission Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public interface RolePermissionRepository extends BaseRepository<RolePermission> {
}