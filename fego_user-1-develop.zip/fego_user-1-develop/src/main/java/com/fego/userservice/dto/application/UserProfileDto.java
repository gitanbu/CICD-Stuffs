package com.fego.userservice.dto.application;

/**
 * <p>
 * Returns User Image and name.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on April 12, 2021
 */
public class UserProfileDto {
    private String userPic;
    private String userName;

    public String getUserPic() {
        return userPic;
    }

    public void setUserPic(String userPic) {
        this.userPic = userPic;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}