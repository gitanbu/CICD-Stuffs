package com.fego.userservice.controller;

import com.fego.foundation.common.response.SuccessResponse;
import com.fego.userservice.common.Constants;
import com.fego.userservice.dto.application.TenantInformationResponseDto;
import com.fego.userservice.service.TenantService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * Tenant Controller
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Api(tags = "Tenant Controller")
@RestController
@RequestMapping("v1/tenant")
public class TenantController {

    private final TenantService tenantService;

    public TenantController(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    @Transactional
    @GetMapping
    @ApiOperation(value = "Returns details of current Tenant")
    public SuccessResponse<TenantInformationResponseDto> getTenantById(HttpServletRequest request) {
        return new SuccessResponse<>(tenantService.getTenantDetails(request.getHeader(Constants.AUTHORIZATION)), HttpStatus.OK);
    }
}
