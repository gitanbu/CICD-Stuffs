package com.fego.userservice.task;

import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.entity.UserSession;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Performs a task when a CRUD operation on UserSession Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public class UserSessionTask implements BaseTask<UserSession> {

    @Override
    public void onCreate(UserSession model) {
        // Method which executes after an UserSession object is created.
    }

    @Override
    public void onUpdate(UserSession model) {
        // Method which executes after an UserSession object is updated.
    }

    @Override
    public void onDelete(UserSession model) {
        // Method which executes after an UserSession object is deleted.
    }
}
