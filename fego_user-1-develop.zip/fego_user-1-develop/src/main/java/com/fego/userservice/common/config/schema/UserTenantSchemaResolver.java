package com.fego.userservice.common.config.schema;

import com.fego.foundation.common.config.interceptor.TenantContext;
import com.fego.userservice.common.Constants;
import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class UserTenantSchemaResolver implements CurrentTenantIdentifierResolver {

    @Override
    public String resolveCurrentTenantIdentifier() {
        String tenantId = TenantContext.getTenantId();
        return Objects.requireNonNullElse(tenantId, Constants.DEFAULT_TENANT_SCHEMA);
    }

    @Override
    public boolean validateExistingCurrentSessions() {
        return true;
    }
}