package com.fego.userservice.controller;

import com.fego.foundation.common.response.SuccessResponse;
import com.fego.foundation.exception.FegoAuthenticationException;
import com.fego.userservice.dto.application.PartnerDto;
import com.fego.userservice.dto.application.PartnerLoginRequestDto;
import com.fego.userservice.dto.application.ResetPasswordDto;
import com.fego.userservice.dto.security.UserDto;
import com.fego.userservice.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * <p>
 * Partner Registration
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on June 1, 2021.
 */
@Api(tags = "Partner Controller")
@RestController
@RequestMapping("v1/partner")
public class PartnerController {

    private final UserService userService;

    public PartnerController(UserService userService) {
        this.userService = userService;
    }

    @Transactional
    @PostMapping("/register")
    @PreAuthorize("hasAuthority('PARTNER_WRITE_PRIVILEGE')")
    @ApiOperation(value = "Sends an registration email for the requested partner")
    public SuccessResponse<Boolean> add(
            @RequestBody @Valid PartnerDto partnerDto) {
        return new SuccessResponse<>(
                userService.registerPartner(partnerDto), HttpStatus.OK);
    }

    @Transactional
    @PostMapping(path = "/change-password")
    @PreAuthorize("hasAuthority('PARTNER_CHANGE_PASSWORD_PRIVILEGE')")
    @ApiOperation(value = "Updates the partner's old password with their new password")
    public SuccessResponse<Boolean> changePassword(@RequestBody @Valid ResetPasswordDto resetPasswordDto) {
        return new SuccessResponse<>(userService.changePassword(resetPasswordDto), HttpStatus.OK);
    }

    @Transactional
    @PatchMapping(path = "/generate-otp")
    @ApiOperation(value = "Generates an OTP to the partner email for forget password")
    public SuccessResponse<Boolean> generateOTPForUser(@RequestParam(value = "email") String email) {
        return new SuccessResponse<>(userService.generateOTPForUser(email), HttpStatus.OK);
    }

    @Transactional
    @PatchMapping(path = "/verify-otp")
    @ApiOperation(value = "Verifies the generated OTP with the user entered OTP")
    public SuccessResponse<Boolean> verifyOTPForUser(@RequestParam(value = "email") String email,
                                                     @RequestParam(value = "otp") String otp) {
        return new SuccessResponse<>(userService.verifyOTPFromUser(email, otp), HttpStatus.OK);
    }

    @Transactional
    @PatchMapping(path = "/update-password")
    @ApiOperation(value = "Updates the partner password with respect to forget password request")
    public SuccessResponse<Boolean> updateNewPassword(@RequestParam(value = "email") String email,
                                                      @RequestParam(value = "password") String password) {
        return new SuccessResponse<>(userService.updateNewPasswordAfterOTPVerification(email, password), HttpStatus.OK);
    }

    @Transactional(noRollbackFor = FegoAuthenticationException.class)
    @PostMapping(path = "/login")
    @ApiOperation(value = "Returns an authentication token for the Partner successful login")
    public SuccessResponse<UserDto> login(@RequestBody @Valid PartnerLoginRequestDto partnerLoginRequestDto) {
        return new SuccessResponse<>(userService.verifyPartnerLogin(partnerLoginRequestDto), HttpStatus.OK);
    }

    @Transactional
    @PatchMapping("/account-aggregator/subscribe")
    @PreAuthorize("hasAuthority('ACCOUNT_AGGREGATOR_UPDATE_PRIVILEGE')")
    @ApiOperation(value = "Enable or disable Account Aggregator of a Tenant")
    public SuccessResponse<Boolean> subscribeAccountAggregator() {
        return new SuccessResponse<>(userService.subscribeAccountAggregator(), HttpStatus.OK);
    }
}
