package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.entity.Tenant;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Repository for Tenant Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 18, 2021.
 */
@Repository
public interface TenantRepository extends BaseRepository<Tenant> {
}