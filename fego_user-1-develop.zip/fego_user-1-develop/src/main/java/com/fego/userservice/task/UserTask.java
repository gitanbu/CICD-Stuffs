package com.fego.userservice.task;

import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.entity.User;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Performs a task when a CRUD operation on User Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public class UserTask implements BaseTask<User> {

    @Override
    public void onCreate(User model) {
        // Method which executes after an User object is created.
    }

    @Override
    public void onUpdate(User model) {
        // Method which executes after an User object is updated.
    }

    @Override
    public void onDelete(User model) {
        // Method which executes after an User object is deleted.
    }
}