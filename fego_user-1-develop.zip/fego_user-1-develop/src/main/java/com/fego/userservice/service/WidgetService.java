package com.fego.userservice.service;

import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.common.base.BaseService;
import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.dto.application.WidgetDto;
import com.fego.userservice.entity.Widget;
import com.fego.userservice.repository.WidgetRepository;
import com.fego.userservice.task.WidgetTask;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * Implements the CRUD operation for the Widgets of a Tenant.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 18, 2021.
 */
@Service
public class WidgetService extends BaseService<Widget, WidgetDto, WidgetTask> {

    public WidgetService(BaseMapper<Widget, WidgetDto> widgetMapper,
                         IdSpecifications<Widget> widgetServiceIdSpecifications, WidgetRepository widgetRepository,
                         BaseTask<Widget> widgetTask) {
        super(widgetRepository, widgetMapper, widgetServiceIdSpecifications, widgetTask);
    }

    /**
     * Returns a list of Widgets that needs to be shown in the application.
     *
     * @return Object - Details of Widget.
     */
    public List<WidgetDto> getWidgetDetails() {
        return findAll();
    }
}
