package com.fego.userservice.service;

import com.fego.foundation.common.config.interceptor.TenantContext;
import com.fego.foundation.common.utils.CacheUtil;
import com.fego.foundation.common.utils.JsonUtil;
import com.fego.foundation.service.App2AppService;
import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.common.base.BaseService;
import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.common.config.App2AppConfig;
import com.fego.userservice.dto.application.TenantDto;
import com.fego.userservice.dto.application.TenantInformationResponseDto;
import com.fego.userservice.entity.Tenant;
import com.fego.userservice.repository.TenantRepository;
import com.fego.userservice.task.TenantTask;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * <p>
 * Implements the CRUD operation for the Tenant of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 18, 2021.
 */
@Service
public class TenantService extends BaseService<Tenant, TenantDto, TenantTask> {

    private static final String CATEGORIZATION_PERCENTAGE = "categorizationPercentage";
    private final App2AppConfig app2AppConfig;
    private final App2AppService app2AppService;

    public TenantService(BaseMapper<Tenant, TenantDto> tenantMapper,
                         IdSpecifications<Tenant> tenantIdSpecifications, TenantRepository tenantRepository,
                         BaseTask<Tenant> tenantTask, App2AppConfig app2AppConfig, App2AppService app2AppService) {
        super(tenantRepository, tenantMapper, tenantIdSpecifications, tenantTask);
        this.app2AppConfig = app2AppConfig;
        this.app2AppService = app2AppService;
    }

    /**
     * Returns details of Tenant.
     *
     * @return Object - Details of Tenant.
     */
    public TenantInformationResponseDto getTenantDetails(String headerValue) {
        var tenantDto = findByTenantName(TenantContext.getTenantId());
        var tenantInformationResponseDto = new TenantInformationResponseDto();
        tenantInformationResponseDto.setTenantDto(tenantDto);
        if (CacheUtil.checkDataCategorizationSubscriptionInPartner().equals(Boolean.TRUE)) {
            tenantInformationResponseDto.setCategorizationPercentage(String.valueOf(getCategorizationPercentage(headerValue)));
        } else {
            tenantInformationResponseDto.setCategorizationPercentage("NA");
        }
        return tenantInformationResponseDto;
    }

    private Integer getCategorizationPercentage(String headerValue) {
        String getUserDetailsUrl = app2AppConfig.getTransactionBaseUrl() + app2AppConfig.getTransaction().get(CATEGORIZATION_PERCENTAGE);
        var percentageAsString = app2AppService.httpGet(getUserDetailsUrl, app2AppService.setHeaders(App2AppService.formAuthorizationHeader(headerValue), null));
        return JsonUtil.convertJsonIntoObject(JsonUtil.parseJsonResponse(percentageAsString).toString(), Integer.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doPatch(Tenant incomingTenant, Tenant toUpdateTenant) {
        if (Objects.nonNull(incomingTenant.getAccountAggregatorSubscribed())) {
            toUpdateTenant.setAccountAggregatorSubscribed(incomingTenant.getAccountAggregatorSubscribed());
        }
    }
}
