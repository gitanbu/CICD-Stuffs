package com.fego.userservice.service;

import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.dto.security.RoleDto;
import com.fego.userservice.entity.Role;
import com.fego.userservice.entity.UserRole;
import com.fego.userservice.repository.RoleRepository;
import com.fego.userservice.repository.UserRoleRepository;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * Operations on Roles of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Service
public class RoleService {

    private final IdSpecifications<UserRole> userRoleIdSpecifications;
    private final RoleRepository roleRepository;
    private final UserRoleRepository userRoleRepository;
    private final RolePermissionService rolePermissionService;

    public RoleService(RoleRepository roleRepository, IdSpecifications<UserRole> userRoleIdSpecifications,
                       UserRoleRepository userRoleRepository, RolePermissionService rolePermissionService) {
        this.userRoleIdSpecifications = userRoleIdSpecifications;
        this.roleRepository = roleRepository;
        this.userRoleRepository = userRoleRepository;
        this.rolePermissionService = rolePermissionService;
    }

    /**
     * Return the role of an user by role id.
     *
     * @param roleId - Role Id of an user.
     * @return Optional Role.
     */
    public Optional<Role> getRoleById(long roleId) {
        return roleRepository.findById(roleId);
    }

    /**
     * To get the roles by user Id.
     *
     * @param userId - User Id
     * @return roleDto - Roles and Permissions of an user.
     */
    public List<RoleDto> getRoleByUserId(long userId) {
        Specification<UserRole> userRoleSpecification = userRoleIdSpecifications.findByUserId(userId).and(userRoleIdSpecifications.notDeleted());
        List<UserRole> userRole = userRoleRepository.findAll(userRoleSpecification);
        List<RoleDto> roleDtoList = new ArrayList<>();
        userRole.forEach(user -> {
            var roleDto = new RoleDto();
            Optional<Role> role = getRoleById(user.getRoleId());
            if (role.isPresent()) {
                var roleEntity = role.get();
                roleDto.setId(roleEntity.getId());
                roleDto.setName(roleEntity.getName());
                roleDto.setDescription(roleEntity.getDescription());
                roleDto.setIsDeleted(roleEntity.isDeleted());
                roleDto.setPermissions(rolePermissionService.getPermissionsByRole(roleEntity.getId()));
            }
            roleDtoList.add(roleDto);
        });
        return roleDtoList;
    }
}