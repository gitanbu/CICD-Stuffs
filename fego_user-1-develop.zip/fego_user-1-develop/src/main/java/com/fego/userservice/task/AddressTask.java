package com.fego.userservice.task;

import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.entity.Address;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Performs a task when a CRUD operation on Address Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public class AddressTask implements BaseTask<Address> {

    @Override
    public void onCreate(Address model) {
        // Method which executes after an Address object is created.
    }

    @Override
    public void onUpdate(Address model) {
        // Method which executes after an Address object is updated.
    }

    @Override
    public void onDelete(Address model) {
        // Method which executes after an Account object is deleted.
    }
}