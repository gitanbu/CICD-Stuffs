package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.entity.UserRole;

/**
 * <p>
 * Repository for UserRole Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public interface UserRoleRepository extends BaseRepository<UserRole> {
}