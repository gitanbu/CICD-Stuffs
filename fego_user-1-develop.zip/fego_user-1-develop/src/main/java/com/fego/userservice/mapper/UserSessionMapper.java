package com.fego.userservice.mapper;

import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.dto.application.UserSessionDto;
import com.fego.userservice.entity.UserSession;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Converts User Session DTO to User Session Entity and vice versa.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on July 27, 2021
 */
@Component
public class UserSessionMapper implements BaseMapper<UserSession, UserSessionDto> {

    public UserSessionDto domainToDto(UserSession userSession) {
        var userSessionDto = new UserSessionDto();
        userSessionDto.setUserId(userSession.getUserId());
        userSessionDto.setAccessDate(userSession.getAccessDate());
        userSessionDto.setStartTime(userSession.getStartTime());
        userSessionDto.setEndTime(userSession.getEndTime());
        userSessionDto.setDuration(userSession.getDuration());
        userSessionDto.setChannel(userSession.getChannel());
        userSessionDto.setId(userSession.getId());
        userSessionDto.setIsDeleted(userSession.isDeleted());
        userSessionDto.setCreatedAt(userSession.getCreatedAt());
        userSessionDto.setUpdatedAt(userSession.getUpdatedAt());
        userSessionDto.setCreatedBy(userSession.getCreatedBy());
        userSessionDto.setUpdatedBy(userSession.getUpdatedBy());
        return userSessionDto;
    }

    public UserSession dtoToDomain(UserSessionDto userSessionDto) {
        var userSession = new UserSession();
        userSession.setUserId(userSessionDto.getUserId());
        userSession.setAccessDate(userSessionDto.getAccessDate());
        userSession.setStartTime(userSessionDto.getStartTime());
        userSession.setEndTime(userSessionDto.getEndTime());
        userSession.setDuration(userSessionDto.getDuration());
        userSession.setChannel(userSessionDto.getChannel());
        userSession.setDeleted(userSessionDto.getIsDeleted());
        userSession.setCreatedBy(userSessionDto.getCreatedBy());
        userSession.setUpdatedBy(userSessionDto.getUpdatedBy());
        return userSession;
    }
}
