package com.fego.userservice.dto.integration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>
 * Details of Consent Request Dto.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsentRequestBodyDto {
    @JsonProperty("FIDataRange")
    private FiDataRangeDto fiDataRange;

    public FiDataRangeDto getFiDataRange() {
        return fiDataRange;
    }

    public void setFiDataRange(FiDataRangeDto fiDataRange) {
        this.fiDataRange = fiDataRange;
    }
}