package com.fego.userservice.dto.application;

/**
 * <p>
 * Returns User Image and Saving Preference.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on April 12, 2021
 */
public class UserProfileDetailDto {
    private String userPic;
    private String userName;
    private String savingPreference;

    public String getSavingPreference() {
        return savingPreference;
    }

    public void setSavingPreference(String savingPreference) {
        this.savingPreference = savingPreference;
    }

    public String getUserPic() {
        return userPic;
    }

    public void setUserPic(String userPic) {
        this.userPic = userPic;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}