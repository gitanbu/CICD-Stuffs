package com.fego.userservice.dto.userengagement;


import java.time.LocalDateTime;

public class SessionAuditDetailDto {
    private Long id;
    private Long userId;
    private String module;
    private LocalDateTime createdAt;

    public SessionAuditDetailDto(Long id, Long userId, String module, LocalDateTime createdAt) {
        this.id = id;
        this.userId = userId;
        this.module = module;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getCreatedAt() {
        return createdAt.toString();
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
