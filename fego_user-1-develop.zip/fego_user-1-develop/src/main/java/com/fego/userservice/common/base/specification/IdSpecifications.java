package com.fego.userservice.common.base.specification;

import com.fego.userservice.common.Constants;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Specification for querying database.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public class IdSpecifications<T> {

    public static final String IS_BATCH_USER = "isBatchUser";
    private static final String ROLE_ID = "roleId";
    private static final String IS_RECENT = "isRecent";
    private static final String NAME = "name";
    private static final String LOCATION = "locationName";
    private static final String EMAIL_ID = "emailId";
    private static final String SESSION_ID = "sessionId";

    public Specification<T> findById(long id) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(Constants.ID), id);
    }

    public Specification<T> findByMobileNumber(String mobileNumber) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(Constants.MOBILE), mobileNumber);
    }

    public Specification<T> notDeleted() {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(Constants.IS_DELETED), Boolean.FALSE);
    }

    public Specification<T> getPermissionsByRoleId(long roleId) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(ROLE_ID), roleId);
    }

    public Specification<T> findByUserId(long userId) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(Constants.USER_ID), userId);
    }

    public Specification<T> findByRecentAddress(long userId) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.and(criteriaBuilder.equal(root.get(Constants.USER_ID), userId),
                criteriaBuilder.equal(root.get(IS_RECENT), Boolean.TRUE));
    }

    public Specification<T> findByTenantName(String tenantId) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(NAME), tenantId);
    }

    public Specification<T> findAddressByAccountId(long accountId) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.and(criteriaBuilder.equal(root.get(Constants.ACCOUNT_ID), accountId));
    }

    public Specification<T> getLocationDetails(String city) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(LOCATION), city);
    }

    public Specification<T> findByEmail(String emailId) {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(EMAIL_ID), emailId.toLowerCase());
    }

    public Specification<T> findByBatchUser() {
        return (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(IS_BATCH_USER), Boolean.TRUE);
    }
}
