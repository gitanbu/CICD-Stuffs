package com.fego.userservice.dto.integration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fego.userservice.dto.application.UserDataDto;

import java.util.List;

/**
 * <p>
 * User details Dto.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProfileResponseDto {

    private Boolean status;
    private String sessionId;
    private UserDataDto userData;
    private List<UserIdentifiersDto> userIdentifiers;

    public UserDataDto getUserData() {
        return userData;
    }

    public void setUserData(UserDataDto userData) {
        this.userData = userData;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public List<UserIdentifiersDto> getUserIdentifiers() {
        return userIdentifiers;
    }

    public void setUserIdentifiers(List<UserIdentifiersDto> userIdentifiers) {
        this.userIdentifiers = userIdentifiers;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
}