package com.fego.userservice.entity;

import com.fego.userservice.common.base.BaseModel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;

/**
 * <p>
 * Holds Address of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Entity
@Table
public class Address extends BaseModel {

    @Column(nullable = false)
    private long userId;
    private String streetOne;
    private String streetTwo;
    private String city;
    private String state;
    private String countryName;
    private String countryAlphaTwo;
    private String countryAlphaThree;
    private String countryUncode;
    private String postalCode;
    private String tier;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private long accountId;
    private Boolean isRecent;
    private Boolean isPartnerAddress;
    private String type;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getStreetOne() {
        return streetOne;
    }

    public void setStreetOne(String streetOne) {
        this.streetOne = streetOne;
    }

    public String getStreetTwo() {
        return streetTwo;
    }

    public void setStreetTwo(String streetTwo) {
        this.streetTwo = streetTwo;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryAlphaTwo() {
        return countryAlphaTwo;
    }

    public void setCountryAlphaTwo(String countryAlphaTwo) {
        this.countryAlphaTwo = countryAlphaTwo;
    }

    public String getCountryAlphaThree() {
        return countryAlphaThree;
    }

    public void setCountryAlphaThree(String countryAlphaThree) {
        this.countryAlphaThree = countryAlphaThree;
    }

    public String getCountryUncode() {
        return countryUncode;
    }

    public void setCountryUncode(String countryUncode) {
        this.countryUncode = countryUncode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    public Boolean getRecent() {
        return isRecent;
    }

    public void setRecent(Boolean recent) {
        isRecent = recent;
    }

    public Boolean getPartnerAddress() {
        return isPartnerAddress;
    }

    public void setPartnerAddress(Boolean partnerAddress) {
        isPartnerAddress = partnerAddress;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}