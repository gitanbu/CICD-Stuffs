package com.fego.userservice.task;

import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.entity.Widget;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Performs a task when a CRUD operation on Widget Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 27, 2021.
 */
@Component
public class WidgetTask implements BaseTask<Widget> {

    @Override
    public void onCreate(Widget model) {
        // Method which executes after an Widget object is created.
    }

    @Override
    public void onUpdate(Widget model) {
        // Method which executes after an Widget object is updated.
    }

    @Override
    public void onDelete(Widget model) {
        // Method which executes after an Widget object is deleted.
    }
}