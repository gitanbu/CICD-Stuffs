package com.fego.userservice.controller;

import com.fego.foundation.common.response.SuccessResponse;
import com.fego.userservice.dto.application.WidgetDto;
import com.fego.userservice.service.WidgetService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 * Widget Controller
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Api(tags = "Widget Controller")
@RestController
@RequestMapping("v1/widget")
public class WidgetController {

    private final WidgetService widgetService;

    public WidgetController(WidgetService widgetService) {
        this.widgetService = widgetService;
    }

    @Transactional
    @GetMapping
    @PreAuthorize("hasAuthority('WIDGET_PREFERENCE_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns a list of Widgets that needs to be shown in the application")
    public SuccessResponse<List<WidgetDto>> getWidgetDetails() {
        return new SuccessResponse<>(widgetService.getWidgetDetails(), HttpStatus.OK);
    }
}