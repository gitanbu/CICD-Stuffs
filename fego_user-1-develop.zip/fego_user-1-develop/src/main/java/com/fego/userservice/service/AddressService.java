package com.fego.userservice.service;

import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.common.base.BaseService;
import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.dto.application.AddressDto;
import com.fego.userservice.entity.Address;
import com.fego.userservice.mapper.AddressMapper;
import com.fego.userservice.repository.AddressRepository;
import com.fego.userservice.task.AddressTask;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * Implements the CRUD operation for the Address of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Service
public class AddressService extends BaseService<Address, AddressDto, AddressTask> {

    private final IdSpecifications<Address> addressIdSpecifications;
    private final AddressRepository addressRepository;
    private final AddressMapper customerAddressMapper;

    public AddressService(BaseMapper<Address, AddressDto> addressMapper,
                          IdSpecifications<Address> addressIdSpecifications, AddressRepository addressRepository,
                          BaseTask<Address> addressTask, AddressMapper customerAddressMapper) {
        super(addressRepository, addressMapper, addressIdSpecifications, addressTask);
        this.addressIdSpecifications = addressIdSpecifications;
        this.addressRepository = addressRepository;
        this.customerAddressMapper = customerAddressMapper;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doPatch(Address incomingAddress, Address toUpdateAddress) {
        if (Objects.nonNull(incomingAddress.getStreetOne())) {
            toUpdateAddress.setStreetOne(incomingAddress.getStreetOne());
        }
        if (Objects.nonNull(incomingAddress.getRecent())) {
            toUpdateAddress.setRecent(incomingAddress.getRecent());
        }
        if (Objects.nonNull(incomingAddress.getCity())) {
            toUpdateAddress.setCity(incomingAddress.getCity());
        }
        toUpdateAddress.setUserId(incomingAddress.getUserId());
        toUpdateAddress.setAccountId(incomingAddress.getAccountId());
        toUpdateAddress.setUpdatedBy(incomingAddress.getUpdatedBy());
    }

    public AddressDto findByRecentAddress(long userId) {
        Specification<Address> addressSpecification = addressIdSpecifications.findByRecentAddress(userId);
        return findOne(addressSpecification);
    }

    public AddressDto findAddressByAccountId(long accountId) {
        Specification<Address> addressSpecification = addressIdSpecifications.findAddressByAccountId(accountId).and(addressIdSpecifications.notDeleted());
        Optional<Address> addressEntity = addressRepository.findOne(addressSpecification);
        if (addressEntity.isEmpty()) {
            return null;
        }
        return customerAddressMapper.domainToDto(addressEntity.get());
    }
}
