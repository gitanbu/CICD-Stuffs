package com.fego.userservice.entity;

import com.fego.userservice.common.base.BaseModel;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * <p>
 * Join table for Role and Permission.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Entity
@Table
public class RolePermission extends BaseModel {

    private long roleId;
    private long permissionId;

    public long getRoleId() {
        return roleId;
    }

    public void setRoleId(long roleId) {
        this.roleId = roleId;
    }

    public long getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(long permissionId) {
        this.permissionId = permissionId;
    }
}