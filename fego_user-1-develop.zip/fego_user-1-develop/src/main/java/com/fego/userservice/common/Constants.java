package com.fego.userservice.common;

/**
 * <p>
 * Application constant values.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public final class Constants {

    // Symbols
    public static final String FORWARD_SLASH = "/";
    // Common
    public static final String EMPTY = "";
    public static final String COMMA = ",";
    public static final String HYPHEN = "-";
    public static final String SUCCESS = "SUCCESS";
    public static final String TRUE_VALUE = "true";
    public static final String BASE_URL = "baseURL";
    public static final String START_OF_DAY = "T00:00:00.000Z";
    public static final String END_OF_DAY = "T23:59:59.999Z";
    public static final String UNDERSCORE = "_";
    public static final String USER_ID = "userId";
    public static final String SESSION_ID = "sessionId";
    public static final String MOBILE = "mobile";
    public static final String ID = "id";
    public static final String IS_LOGGED_IN = "isLoggedIn";
    public static final String CONSENT_HANDLE = "consentHandle";
    public static final String AUTHORIZATION = "Authorization";
    public static final String IS_DELETED = "isDeleted";
    public static final String SEMI_COLON = ";";
    public static final String SPACE = " ";
    public static final String DOT = ".";
    public static final String DEFAULT_TENANT_SCHEMA = "common";
    public static final String TENANT_ID = "tenantId";
    public static final String ACCOUNT_ID = "accountId";
    public static final String TIME_ZONE = "timeZone";
    public static final String IS_DATA_CATEGORIZATION_SUBSCRIBED = "isDataCategorizationSubscribed";

    private Constants() {
    }
}
