package com.fego.userservice.common.base;

import org.springframework.stereotype.Component;

/**
 * <p>
 * BaseMapper for converting domainToDto and vice-versa.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public interface BaseMapper<M extends BaseModel, D extends BaseDto> {
    D domainToDto(M baseModel);

    M dtoToDomain(D baseDto);
}