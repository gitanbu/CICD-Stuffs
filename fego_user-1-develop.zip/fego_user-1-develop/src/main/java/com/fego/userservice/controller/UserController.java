package com.fego.userservice.controller;

import com.fego.foundation.common.response.SuccessResponse;
import com.fego.userservice.common.Constants;
import com.fego.userservice.dto.application.AccountAddressDto;
import com.fego.userservice.dto.application.AddressDetailsDto;
import com.fego.userservice.dto.application.GenericResponseDto;
import com.fego.userservice.dto.application.SavingPreferenceUpdateDto;
import com.fego.userservice.dto.application.SessionAuditDto;
import com.fego.userservice.dto.application.UserDataDto;
import com.fego.userservice.dto.application.UserDetailsDto;
import com.fego.userservice.dto.application.UserProfileDetailDto;
import com.fego.userservice.dto.application.UserProfileDto;
import com.fego.userservice.dto.integration.CustomerRegistrationRequestDto;
import com.fego.userservice.dto.integration.CustomerRegistrationVerifyDto;
import com.fego.userservice.dto.integration.HoldersDto;
import com.fego.userservice.dto.integration.LoginDto;
import com.fego.userservice.dto.integration.LoginVerifyDto;
import com.fego.userservice.dto.security.UserDto;
import com.fego.userservice.dto.userengagement.FunnelDropOutDto;
import com.fego.userservice.service.LoginService;
import com.fego.userservice.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

/**
 * <p>
 * User Registration
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Api(tags = "User Controller")
@RestController
@RequestMapping("v1/user")
public class UserController {

    private final UserService userService;
    private final LoginService loginService;

    public UserController(UserService userService, LoginService loginService) {
        this.userService = userService;
        this.loginService = loginService;
    }

    @Transactional
    @PostMapping("/register")
    @ApiOperation(value = "Returns OTP for the entered mobile number")
    public SuccessResponse<Object> add(
            @RequestBody @Valid CustomerRegistrationRequestDto userRegistrationDto) {
        return new SuccessResponse<>(
                userService.getOtpReference(userRegistrationDto), HttpStatus.OK);
    }

    @Transactional
    @PostMapping("/register/verify")
    @ApiOperation(value = "Verifies the OTP received for registration")
    public SuccessResponse<Object> verifyOtp(
            @RequestBody @Valid CustomerRegistrationVerifyDto customerRegistrationVerifyDto) {
        return new SuccessResponse<>(userService.verifyOtp(customerRegistrationVerifyDto),
                HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/detail")
    @ApiOperation(value = "Returns details of an user by mobile number")
    public SuccessResponse<UserDto> getUserByMobile(@RequestParam(name = "type") String type, @RequestParam(name = "searchValue", required = false) String searchValue) {
        return new SuccessResponse<>(userService.getUserDetails(searchValue, type), HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/check")
    @ApiOperation(value = "Returns boolean value whether an user exists (or) not")
    public SuccessResponse<Boolean> checkUserExist(@RequestParam(name = "searchValue") String searchValue) {
        return new SuccessResponse<>(userService.checkUserExists(searchValue), HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/saving-preference")
    @PreAuthorize("hasAuthority('CUSTOMER_SAVING_PREFERENCE_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns Saving Preference of an user")
    public SuccessResponse<Integer> getSavingPreference() {
        return new SuccessResponse<>(userService.fetchSavingPreference(),
                HttpStatus.OK);
    }

    @Transactional
    @PatchMapping("/saving-preference")
    @PreAuthorize("hasAuthority('CUSTOMER_SAVING_PREFERENCE_UPDATE_PRIVILEGE')")
    @ApiOperation(value = "Updates Saving Preference of an user")
    public SuccessResponse<Object> updateSavingPreference(
            @RequestBody @Valid SavingPreferenceUpdateDto savingPreferenceUpdateDto) {
        return new SuccessResponse<>(userService.updateSavingPreference(savingPreferenceUpdateDto),
                HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/details")
    @PreAuthorize("hasAuthority('CUSTOMER_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns User Details of all active users")
    public SuccessResponse<List<UserDetailsDto>> getUsers() {
        return new SuccessResponse<>(userService.getUserDetailsForBatch(), HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/details/{id}")
    @PreAuthorize("hasAuthority('CUSTOMER_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns User Details of an active user")
    public SuccessResponse<UserDetailsDto> getUsers(@PathVariable(name = "id") long id) {
        return new SuccessResponse<>(userService.getUserDetailsForOnboard(id), HttpStatus.OK);
    }

    @Transactional
    @PutMapping("/update/{userId}")
    @PreAuthorize("hasAuthority('CUSTOMER_UPDATE_PRIVILEGE')")
    @ApiOperation(value = "Updates User Details of an User with the details received from OneMoney")
    public SuccessResponse<GenericResponseDto> update(@PathVariable(Constants.USER_ID) long userId, @RequestBody @Valid List<HoldersDto> holdersDto) {
        return new SuccessResponse<>(userService.updateUserDetails(userId, holdersDto), HttpStatus.OK);
    }

    @Transactional
    @GetMapping
    @PreAuthorize("hasAuthority('CUSTOMER_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns details of an user")
    public SuccessResponse<UserDataDto> getUser() {
        return new SuccessResponse<>(userService.getUserDetails(), HttpStatus.OK);
    }

    @Transactional
    @PatchMapping("/update-name/{userName}")
    @PreAuthorize("hasAuthority('CUSTOMER_UPDATE_PRIVILEGE')")
    @ApiOperation(value = "Updates Name of an user")
    public SuccessResponse<GenericResponseDto> updateUserName(@PathVariable("userName") String userName) {
        return new SuccessResponse<>(userService.updateUserName(userName), HttpStatus.OK);
    }

    @Transactional
    @PatchMapping("/update/session")
    @PreAuthorize("hasAuthority('CUSTOMER_UPDATE_PRIVILEGE')")
    @ApiOperation(value = "Updates the user session")
    public SuccessResponse<Boolean> updateUserSession(@RequestParam(name = "sessionId") long sessionId) {
        return new SuccessResponse<>(userService.updateUserSession(sessionId),
                HttpStatus.OK);
    }

    @Transactional
    @PatchMapping("/update/onboard/status")
    @PreAuthorize("hasAuthority('CUSTOMER_UPDATE_PRIVILEGE')")
    @ApiOperation(value = "Updates User with Account Linked Status after linking at least any one of the user account")
    public SuccessResponse<GenericResponseDto> update() {
        return new SuccessResponse<>(userService.updateUserOnboardStatus(), HttpStatus.OK);
    }

    @Transactional
    @PostMapping("/address")
    @PreAuthorize("hasAuthority('CUSTOMER_ADDRESS_WRITE_PRIVILEGE')")
    @ApiOperation(value = "Inserts addresses of an user based on accounts")
    public SuccessResponse<GenericResponseDto> updateUserAddress(@RequestBody @Valid List<AccountAddressDto> accountAddressDto) {
        return new SuccessResponse<>(userService.updateUserAddress(accountAddressDto), HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/profile")
    @PreAuthorize("hasAuthority('CUSTOMER_PROFILE_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns Customer Image and Name")
    public SuccessResponse<UserProfileDto> profile() {
        return new SuccessResponse<>(userService.getProfile(), HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/profile/detail")
    @PreAuthorize("hasAuthority('CUSTOMER_PROFILE_DETAIL_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns Customer Image and Saving Preference")
    public SuccessResponse<UserProfileDetailDto> profileDetail() {
        return new SuccessResponse<>(userService.getProfileDetail(), HttpStatus.OK);
    }

    @Transactional
    @PatchMapping("/profile/detail")
    @PreAuthorize("hasAuthority('CUSTOMER_PROFILE_DETAIL_UPDATE_PRIVILEGE')")
    @ApiOperation(value = "Returns Customer Image and Saving Preference")
    public SuccessResponse<UserProfileDetailDto> updateProfileDetail(@RequestBody @Valid UserProfileDetailDto userProfileDetailDto) {
        return new SuccessResponse<>(userService.updateProfileDetail(userProfileDetailDto), HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/address/details")
    @PreAuthorize("hasAuthority('CUSTOMER_ADDRESS_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns User Address Details of all active users")
    public SuccessResponse<List<AddressDetailsDto>> getUserAddress() {
        return new SuccessResponse<>(userService.getUserAddress(), HttpStatus.OK);
    }

    @Transactional
    @PostMapping("/audit")
    @ApiOperation(value = "Creates a record in session audit table")
    public SuccessResponse<Boolean> addAuditRecord(@RequestBody @Valid SessionAuditDto sessionAuditDto) {
        return new SuccessResponse<>(userService.addAuditRecord(sessionAuditDto), HttpStatus.OK);
    }

    @Transactional
    @PostMapping("/login")
    @ApiOperation(value = "Returns OTP for the entered mobile number")
    public SuccessResponse<Object> getOtp(@RequestBody @Valid LoginDto loginDto) {
        return new SuccessResponse<>(loginService.login(loginDto), HttpStatus.OK);
    }

    @Transactional
    @PostMapping("/login/verify")
    @ApiOperation(value = "Verifies the OTP received for login")
    public SuccessResponse<Object> verifyOtp(
            @RequestBody @Valid LoginVerifyDto loginVerifyDto, HttpServletRequest httpServletRequest) {
        return new SuccessResponse<>(loginService.verifyOtp(loginVerifyDto, httpServletRequest),
                HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/funnel-dropout")
    @PreAuthorize("hasAuthority('USER_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns last two months user Details of all active users")
    public SuccessResponse<List<FunnelDropOutDto>> getFunnelDropOutUserDetails() {
        return new SuccessResponse<>(userService.getFunnelDropOutUserDetails(), HttpStatus.OK);
    }

}
