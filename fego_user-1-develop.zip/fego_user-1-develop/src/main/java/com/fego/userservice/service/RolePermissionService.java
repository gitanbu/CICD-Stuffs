package com.fego.userservice.service;

import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.dto.security.PermissionDto;
import com.fego.userservice.entity.Permission;
import com.fego.userservice.entity.RolePermission;
import com.fego.userservice.repository.PermissionRepository;
import com.fego.userservice.repository.RolePermissionRepository;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <p>
 * Operations on Permissions of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Service
public class RolePermissionService {

    private final RolePermissionRepository rolePermissionRepository;
    private final IdSpecifications<RolePermission> rolePermissionIdSpecifications;
    private final IdSpecifications<Permission> permissionIdSpecifications;
    private final PermissionRepository permissionRepository;

    public RolePermissionService(RolePermissionRepository rolePermissionRepository, IdSpecifications<RolePermission> rolePermissionIdSpecifications, IdSpecifications<Permission> permissionIdSpecifications, PermissionRepository permissionRepository) {
        this.rolePermissionRepository = rolePermissionRepository;
        this.rolePermissionIdSpecifications = rolePermissionIdSpecifications;
        this.permissionIdSpecifications = permissionIdSpecifications;
        this.permissionRepository = permissionRepository;
    }

    /**
     * Returns the list of permissions of an user based on the Role.
     *
     * @param roleId - Role Id of an user.
     * @return permissions - List of Permissions.
     */
    public List<PermissionDto> getPermissionsByRole(long roleId) {
        Specification<RolePermission> roleSpecification = rolePermissionIdSpecifications.getPermissionsByRoleId(roleId).and(rolePermissionIdSpecifications.notDeleted());
        List<RolePermission> rolePermissions = rolePermissionRepository.findAll(roleSpecification);
        List<PermissionDto> permissions = new ArrayList<>();
        rolePermissions.forEach(row -> {
            Specification<Permission> permissionSpecification = permissionIdSpecifications.findById(row.getPermissionId()).and(permissionIdSpecifications.notDeleted());
            Optional<Permission> permission = permissionRepository.findOne(permissionSpecification);
            if (permission.isPresent()) {
                var permissionDto = new PermissionDto();
                permissionDto.setId(permission.get().getId());
                permissionDto.setOperation(permission.get().getOperation());
                permissionDto.setIsDeleted(permission.get().isDeleted());
                permissions.add(permissionDto);
            }
        });
        return permissions;
    }
}