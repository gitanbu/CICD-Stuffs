package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.dto.userengagement.UserSessionDetailDto;
import com.fego.userservice.entity.UserSession;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * <p>
 * User session repository.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on July 27, 2021
 */
@Repository
public interface UserSessionRepository extends BaseRepository<UserSession> {

    @Query(value = "select NEW com.fego.userservice.dto.userengagement.UserSessionDetailDto (u.id, u.userId, u.accessDate, u.startTime, u.endTime, u.duration, u.channel) FROM UserSession u where u.isDeleted=false and u.accessDate >= :startDate and u.accessDate <= :endDate")
    List<UserSessionDetailDto> getUserSessionDetails(@Param(value = "startDate") LocalDate startDate, @Param(value = "endDate") LocalDate endDate);
}