package com.fego.userservice.dto.security;

import org.springframework.security.core.GrantedAuthority;

/**
 * <p>
 * Permission details.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on March 23, 2021.
 */
public class PermissionDto implements GrantedAuthority {

    private Long id;
    private String operation;
    private boolean isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    @Override
    public String getAuthority() {
        return operation;
    }
}