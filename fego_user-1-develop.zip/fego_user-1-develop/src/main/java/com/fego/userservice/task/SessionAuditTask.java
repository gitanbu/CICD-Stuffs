package com.fego.userservice.task;

import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.entity.SessionAudit;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Performs a task when a CRUD operation on SessionAudit Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on Jul 29, 2021.
 */
@Component
public class SessionAuditTask implements BaseTask<SessionAudit> {

    @Override
    public void onCreate(SessionAudit model) {
        // Method which executes after an SessionAudit object is created.
    }

    @Override
    public void onUpdate(SessionAudit model) {
        // Method which executes after an SessionAudit object is updated.
    }

    @Override
    public void onDelete(SessionAudit model) {
        // Method which executes after an SessionAudit object is deleted.
    }
}