package com.fego.userservice.mapper;

import com.fego.foundation.aws.storage.AwsStorageConfig;
import com.fego.foundation.common.utils.CommonUtil;
import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.dto.application.UserDataDto;
import com.fego.userservice.entity.User;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;

import static com.fego.foundation.common.Constants.COMMA;
import static com.fego.foundation.common.Constants.EMPTY;
import static com.fego.foundation.common.Constants.PROFILE_FOLDER;

/**
 * <p>
 * Converts User DTO to User Entity and vice versa.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public class UserMapper implements BaseMapper<User, UserDataDto> {

    private final AwsStorageConfig awsStorageConfig;

    public UserMapper(AwsStorageConfig awsStorageConfig) {
        this.awsStorageConfig = awsStorageConfig;
    }

    public UserDataDto domainToDto(User user) {
        var userDataDto = new UserDataDto();
        userDataDto.setFirstName(user.getFirstName());
        userDataDto.setMiddleName(user.getMiddleName());
        userDataDto.setLastName(user.getLastName());
        userDataDto.setMobile(user.getMobile());
        if (Objects.nonNull(user.getTermsAndConditions())) {
            userDataDto.setTermsAndConditions(user.getTermsAndConditions());
        }
        userDataDto.setIsKycVerified(user.getKycVerified());
        userDataDto.setEmail(user.getEmailId().toLowerCase());
        userDataDto.setAddressId(user.getAddressId());
        userDataDto.setPan(user.getPan());
        userDataDto.setDob(user.getDob());
        userDataDto.setAge(user.getAge());
        userDataDto.setGender(user.getGender());
        userDataDto.setType(user.getType());
        userDataDto.setIsOtp(user.getOtp());
        userDataDto.setVua(user.getVua());
        userDataDto.setSavingPreference(user.getSavingPreference());
        userDataDto.setTenant(user.getTenant());
        userDataDto.setTier(user.getTier());
        userDataDto.setImage(Objects.nonNull(user.getImage()) ? CommonUtil.formImageBucketURI(awsStorageConfig.getImagesBucketUrl(), PROFILE_FOLDER, user.getId(), user.getImage()) : null);
        userDataDto.setOnboardingStatus(user.getOnboardingStatus());
        userDataDto.setForgetPasswordKey(user.getForgetPasswordKey());
        userDataDto.setPassword(user.getPassword());
        userDataDto.setUserType(user.getUserType());
        userDataDto.setPartnerLoggedIn(user.getPartnerLoggedIn());
        userDataDto.setTimeZone(user.getTimeZone());
        userDataDto.setBatchUser(user.getBatchUser());
        userDataDto.setVerificationTokenSentTime(user.getVerificationTokenSentTime());
        userDataDto.setFailureAttempts(user.getFailureAttempts());
        userDataDto.setLockTime(user.getLockTime());
        userDataDto.setAccountLocked(user.getAccountLocked());
        userDataDto.setPasswordChangedTime(user.getPasswordChangedTime());
        if (user.getOldPassword() == null || user.getOldPassword().trim().length() == 0) {
            userDataDto.setOldPassword(Collections.emptyList());
        } else {
            userDataDto.setOldPassword(Arrays.asList(user.getOldPassword().split(COMMA)));
        }
        userDataDto.setId(user.getId());
        userDataDto.setCreatedAt(user.getCreatedAt());
        userDataDto.setUpdatedAt(user.getUpdatedAt());
        userDataDto.setIsDeleted(user.isDeleted());
        userDataDto.setCreatedBy(user.getCreatedBy());
        userDataDto.setUpdatedBy(user.getUpdatedBy());
        return userDataDto;
    }

    public User dtoToDomain(UserDataDto userDataDto) {
        var user = new User();
        user.setFirstName(userDataDto.getFirstName());
        user.setMiddleName(userDataDto.getMiddleName());
        user.setLastName(userDataDto.getLastName());
        user.setMobile(userDataDto.getMobile());
        user.setTermsAndConditions(userDataDto.getTermsAndConditions());
        user.setKycVerified(userDataDto.getIsKycVerified());
        user.setEmailId(userDataDto.getEmail());
        user.setAddressId(userDataDto.getAddressId());
        user.setPan(userDataDto.getPan());
        user.setDob(userDataDto.getDob());
        user.setAge(userDataDto.getAge());
        user.setGender(userDataDto.getGender());
        user.setType(userDataDto.getType());
        user.setOtp(userDataDto.getIsOtp());
        user.setVua(userDataDto.getVua());
        user.setSavingPreference(userDataDto.getSavingPreference());
        user.setTenant(userDataDto.getTenant());
        user.setTier(userDataDto.getTier());
        user.setImage(userDataDto.getImage());
        user.setOnboardingStatus(userDataDto.getOnboardingStatus());
        user.setForgetPasswordKey(userDataDto.getForgetPasswordKey());
        user.setPassword(userDataDto.getPassword());
        user.setUserType(userDataDto.getUserType());
        user.setPartnerLoggedIn(userDataDto.getPartnerLoggedIn());
        user.setTimeZone(userDataDto.getTimeZone());
        user.setBatchUser(userDataDto.getBatchUser());
        user.setVerificationTokenSentTime(userDataDto.getVerificationTokenSentTime());
        user.setFailureAttempts(userDataDto.getFailureAttempts());
        user.setLockTime(userDataDto.getLockTime());
        user.setAccountLocked(userDataDto.getAccountLocked());
        user.setPasswordChangedTime(userDataDto.getPasswordChangedTime());
        if (CollectionUtils.isEmpty(userDataDto.getOldPassword())) {
            user.setOldPassword(EMPTY);
        } else {
            user.setOldPassword(StringUtils.join(userDataDto.getOldPassword(), COMMA));
        }
        user.setCreatedBy(Objects.nonNull(userDataDto.getCreatedBy()) ? userDataDto.getCreatedBy() : 0L);
        user.setUpdatedBy(Objects.nonNull(userDataDto.getUpdatedBy()) ? userDataDto.getUpdatedBy() : 0L);
        user.setDeleted(userDataDto.getIsDeleted());
        return user;
    }
}
