package com.fego.userservice.mapper;

import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.dto.application.WidgetDto;
import com.fego.userservice.entity.Widget;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Converts Widget DTO to Widget Entity and vice versa.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 18, 2021.
 */
@Component
public class WidgetMapper implements BaseMapper<Widget, WidgetDto> {

    public WidgetDto domainToDto(Widget widget) {
        var widgetDto = new WidgetDto();
        widgetDto.setWidgetName(widget.getWidgetName());
        widgetDto.setIsSubscribed(widget.getIsSubscribed());
        widgetDto.setType(widget.getType());
        widgetDto.setDescription(widget.getDescription());
        widgetDto.setId(widget.getId());
        widgetDto.setIsDeleted(widget.isDeleted());
        widgetDto.setCreatedAt(widget.getCreatedAt());
        widgetDto.setUpdatedAt(widget.getUpdatedAt());
        widgetDto.setCreatedBy(widget.getCreatedBy());
        widgetDto.setUpdatedBy(widget.getUpdatedBy());
        return widgetDto;
    }

    public Widget dtoToDomain(WidgetDto widgetDto) {
        var widget = new Widget();
        widget.setWidgetName(widgetDto.getWidgetName());
        widget.setIsSubscribed(widgetDto.getIsSubscribed());
        widget.setType(widgetDto.getType());
        widget.setDescription(widgetDto.getDescription());
        widget.setDeleted(widgetDto.getIsDeleted());
        widget.setCreatedBy(widgetDto.getCreatedBy());
        widget.setUpdatedBy(widgetDto.getUpdatedBy());
        return widget;
    }
}
