package com.fego.userservice.common.base;

import com.fego.userservice.common.Constants;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.lang.NonNull;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * Base repository implementation of a table which every table extends.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public class BaseRepositoryImpl<T extends BaseModel> extends SimpleJpaRepository<T, Long> implements BaseRepository<T> {

    private final EntityManager entityManager;
    private final Specification<T> notDeleted = (root, criteriaQuery, criteriaBuilder) -> criteriaBuilder.equal(root.get(Constants.IS_DELETED), Boolean.FALSE);

    public BaseRepositoryImpl(JpaEntityInformation<T, ?> entityInformation, EntityManager entityManager) {
        super(entityInformation, entityManager);
        this.entityManager = entityManager;
    }

    @Override
    public Optional<T> findOne(Specification<T> specification) {
        Specification<T> baseSpec = Objects.requireNonNull(specification).and(notDeleted);
        return super.findOne(baseSpec);
    }

    @Override
    public Page<T> findAll(@NonNull Pageable pageable) {
        return super.findAll(notDeleted, pageable);
    }

    @Override
    public Page<T> findAll(Specification<T> specification, @NonNull Pageable pageable) {
        Specification<T> baseSpec = notDeleted.and(specification);
        return super.findAll(baseSpec, Objects.requireNonNull(pageable));
    }

    @Override
    public long count() {
        return super.count(notDeleted);
    }

    @Override
    public long count(Specification<T> spec) {
        return super.count(notDeleted.and(spec));
    }

    @Override
    @Transactional
    public void refresh(T t) {
        entityManager.refresh(t);
    }
}