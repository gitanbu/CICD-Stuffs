package com.fego.userservice.dto.application;

import com.fego.userservice.dto.integration.HoldersDto;

/**
 * <p>
 * DTO which maps user address with account.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on April 11, 2021.
 */
public class AccountAddressDto {
    private long accountId;
    private HoldersDto holdersDto;
    private Boolean isRecentAddress;
    private long userId;

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    public HoldersDto getHoldersDto() {
        return holdersDto;
    }

    public void setHoldersDto(HoldersDto holdersDto) {
        this.holdersDto = holdersDto;
    }

    public Boolean getRecentAddress() {
        return isRecentAddress;
    }

    public void setRecentAddress(Boolean recentAddress) {
        isRecentAddress = recentAddress;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }
}