package com.fego.userservice.dto.security;

import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.List;

/**
 * <p>
 * User details.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on March 23, 2021.
 */
public class UserDto {
    private long id;
    private String userType;
    private String email;
    private String mobile;
    private String firstName;
    private Collection<GrantedAuthority> authorities;
    private Boolean isDeleted;
    private List<RoleDto> roles;
    private String tokenId;
    private String tenant;
    private String onboardStatus;
    private long partnerId;
    private String partnerPrefix;
    private Boolean isPartnerLoggedIn;
    private String timeZone;
    private Boolean isChangePasswordRequired;
    private long sessionId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Collection<GrantedAuthority> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Collection<GrantedAuthority> authorities) {
        this.authorities = authorities;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public List<RoleDto> getRoles() {
        return roles;
    }

    public void setRoles(List<RoleDto> roles) {
        this.roles = roles;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public long getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(long partnerId) {
        this.partnerId = partnerId;
    }

    public String getPartnerPrefix() {
        return partnerPrefix;
    }

    public void setPartnerPrefix(String partnerPrefix) {
        this.partnerPrefix = partnerPrefix;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public String getOnboardStatus() {
        return onboardStatus;
    }

    public void setOnboardStatus(String onboardStatus) {
        this.onboardStatus = onboardStatus;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Boolean getPartnerLoggedIn() {
        return isPartnerLoggedIn;
    }

    public void setPartnerAccountLoggedIn(Boolean isPartnerLoggedIn) {
        this.isPartnerLoggedIn = isPartnerLoggedIn;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public Boolean getChangePasswordRequired() {
        return isChangePasswordRequired;
    }

    public void setChangePasswordRequired(Boolean changePasswordRequired) {
        isChangePasswordRequired = changePasswordRequired;
    }

    public long getSessionId() {
        return sessionId;
    }

    public void setSessionId(long sessionId) {
        this.sessionId = sessionId;
    }
}
