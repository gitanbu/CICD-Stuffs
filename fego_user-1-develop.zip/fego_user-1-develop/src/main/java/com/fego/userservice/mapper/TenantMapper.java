package com.fego.userservice.mapper;

import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.dto.application.TenantDto;
import com.fego.userservice.entity.Tenant;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Converts Tenant DTO to Tenant Entity and vice versa.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 18, 2021.
 */
@Component
public class TenantMapper implements BaseMapper<Tenant, TenantDto> {

    public TenantDto domainToDto(Tenant tenant) {
        var tenantDto = new TenantDto();
        tenantDto.setName(tenant.getName());
        tenantDto.setDescription(tenant.getDescription());
        tenantDto.setAddress(tenant.getAddress());
        tenantDto.setType(tenant.getType());
        tenantDto.setAccountAggregator(tenant.getAccountAggregator());
        tenantDto.setOnboardingSubscribed(tenant.getOnboardingSubscribed());
        tenantDto.setDataCategorizationSubscribed(tenant.getDataCategorizationSubscribed());
        tenantDto.setAccountAggregatorSubscribed(tenant.getAccountAggregatorSubscribed());
        tenantDto.setId(tenant.getId());
        tenantDto.setIsDeleted(tenant.isDeleted());
        tenantDto.setCreatedAt(tenant.getCreatedAt());
        tenantDto.setUpdatedAt(tenant.getUpdatedAt());
        tenantDto.setCreatedBy(tenant.getCreatedBy());
        tenantDto.setUpdatedBy(tenant.getUpdatedBy());
        return tenantDto;
    }

    public Tenant dtoToDomain(TenantDto tenantDto) {
        var tenant = new Tenant();
        tenant.setName(tenantDto.getName());
        tenant.setDescription(tenantDto.getDescription());
        tenant.setAddress(tenantDto.getAddress());
        tenant.setType(tenantDto.getType());
        tenant.setAccountAggregator(tenantDto.getAccountAggregator());
        tenant.setOnboardingSubscribed(tenantDto.getOnboardingSubscribed());
        tenant.setDataCategorizationSubscribed(tenantDto.getDataCategorizationSubscribed());
        tenant.setAccountAggregatorSubscribed(tenantDto.getAccountAggregatorSubscribed());
        tenant.setDeleted(tenantDto.getIsDeleted());
        tenant.setCreatedBy(tenantDto.getCreatedBy());
        tenant.setUpdatedBy(tenantDto.getUpdatedBy());
        return tenant;
    }
}
