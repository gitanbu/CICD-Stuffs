package com.fego.userservice.controller;

import com.fego.foundation.common.response.SuccessResponse;
import com.fego.userservice.dto.userengagement.SessionAuditDetailDto;
import com.fego.userservice.dto.userengagement.UserSessionDetailDto;
import com.fego.userservice.service.SessionAuditService;
import com.fego.userservice.service.UserSessionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@Api(tags = "Session Controller")
@RestController
@RequestMapping("v1/session")
public class SessionController {

    private final UserSessionService userSessionService;
    private final SessionAuditService sessionAuditService;

    public SessionController(UserSessionService userSessionService, SessionAuditService sessionAuditService) {
        this.userSessionService = userSessionService;
        this.sessionAuditService = sessionAuditService;
    }


    @Transactional
    @GetMapping
    @PreAuthorize("hasAuthority('USER_SESSION_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns last two months user session detail of all active users")
    public SuccessResponse<List<UserSessionDetailDto>> getUserSessionDetails() {
        return new SuccessResponse<>(userSessionService.getUserSessionDetails(), HttpStatus.OK);
    }

    @Transactional
    @GetMapping("/audit")
    @PreAuthorize("hasAuthority('SESSION_AUDIT_READ_PRIVILEGE')")
    @ApiOperation(value = "Returns last month session audit detail of all active users")
    public SuccessResponse<List<SessionAuditDetailDto>> getSessionAudit() {
        return new SuccessResponse<>(sessionAuditService.getSessionAudit(), HttpStatus.OK);
    }
}
