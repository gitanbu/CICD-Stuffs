package com.fego.userservice.mapper;

import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.dto.application.AddressDto;
import com.fego.userservice.entity.Address;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Converts Address DTO to Address Entity and vice versa.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public class AddressMapper implements BaseMapper<Address, AddressDto> {

    public AddressDto domainToDto(Address address) {
        var addressDataDto = new AddressDto();
        addressDataDto.setUserId(address.getUserId());
        addressDataDto.setStreetOne(address.getStreetOne());
        addressDataDto.setStreetTwo(address.getStreetTwo());
        addressDataDto.setCity(address.getCity());
        addressDataDto.setState(address.getState());
        addressDataDto.setCountryName(address.getCountryName());
        addressDataDto.setCountryAlphaTwo(address.getCountryAlphaTwo());
        addressDataDto.setCountryAlphaThree(address.getCountryAlphaThree());
        addressDataDto.setCountryUncode(address.getCountryUncode());
        addressDataDto.setPostalCode(address.getPostalCode());
        addressDataDto.setType(address.getType());
        addressDataDto.setAccountId(address.getAccountId());
        addressDataDto.setPartnerAddress(address.getPartnerAddress());
        addressDataDto.setTier(address.getTier());
        addressDataDto.setLatitude(address.getLatitude());
        addressDataDto.setLongitude(address.getLongitude());
        addressDataDto.setRecent(address.getRecent());
        addressDataDto.setId(address.getId());
        addressDataDto.setIsDeleted(address.isDeleted());
        addressDataDto.setCreatedAt(address.getCreatedAt());
        addressDataDto.setUpdatedAt(address.getUpdatedAt());
        addressDataDto.setCreatedBy(address.getCreatedBy());
        addressDataDto.setUpdatedBy(address.getUpdatedBy());
        return addressDataDto;
    }

    public Address dtoToDomain(AddressDto addressDataDto) {
        var address = new Address();
        address.setUserId(addressDataDto.getUserId());
        address.setStreetOne(addressDataDto.getStreetOne());
        address.setStreetTwo(addressDataDto.getStreetTwo());
        address.setCity(addressDataDto.getCity());
        address.setState(addressDataDto.getState());
        address.setCountryName(addressDataDto.getCountryName());
        address.setCountryAlphaTwo(addressDataDto.getCountryAlphaThree());
        address.setCountryAlphaThree(addressDataDto.getCountryAlphaThree());
        address.setCountryUncode(addressDataDto.getCountryUncode());
        address.setPostalCode(addressDataDto.getPostalCode());
        address.setType(addressDataDto.getType());
        address.setTier(addressDataDto.getTier());
        address.setLatitude(addressDataDto.getLatitude());
        address.setLongitude(addressDataDto.getLongitude());
        address.setAccountId(addressDataDto.getAccountId());
        address.setPartnerAddress(addressDataDto.getPartnerAddress());
        address.setRecent(addressDataDto.getRecent());
        address.setDeleted(addressDataDto.getIsDeleted());
        address.setCreatedBy(addressDataDto.getCreatedBy());
        address.setUpdatedBy(addressDataDto.getUpdatedBy());
        return address;
    }
}