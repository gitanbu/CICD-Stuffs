package com.fego.userservice.dto.application;

import java.math.BigDecimal;

/**
 * <p>
 * Address Details of an User.
 * </p>
 *
 * @author Subbulakshmi Ganesan created on April 29, 2021.
 */
public class AddressDetailsDto {

    private long userId;
    private String streetOne;
    private String city;
    private String tier;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Boolean isRecent;

    public AddressDetailsDto(long userId, String streetOne, String city, String tier, BigDecimal latitude, BigDecimal longitude, Boolean isRecent) {
        this.userId = userId;
        this.streetOne = streetOne;
        this.city = city;
        this.tier = tier;
        this.latitude = latitude;
        this.longitude = longitude;
        this.isRecent = isRecent;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getStreetOne() {
        return streetOne;
    }

    public void setStreetOne(String streetOne) {
        this.streetOne = streetOne;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public Boolean getRecent() {
        return isRecent;
    }

    public void setRecent(Boolean recent) {
        isRecent = recent;
    }
}
