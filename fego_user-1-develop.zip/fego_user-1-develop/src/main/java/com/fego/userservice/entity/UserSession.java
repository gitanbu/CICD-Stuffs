package com.fego.userservice.entity;

import com.fego.userservice.common.base.BaseModel;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * Holds session details of an user.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on July 27, 2021
 */
@Entity
@Table
public class UserSession extends BaseModel {

    private long userId;
    private LocalDate accessDate;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private long duration;
    private String channel;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public LocalDate getAccessDate() {
        return accessDate;
    }

    public void setAccessDate(LocalDate accessDate) {
        this.accessDate = accessDate;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
