package com.fego.userservice.dto.application;

import com.fego.userservice.common.Constants;

import java.time.LocalDate;
import java.util.Objects;

/**
 * <p>
 * Basic Details of an User.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public class UserDetailsDto {
    private long id;
    private String gender;
    private Integer age;
    private String tier;
    private String firstName;
    private String middleName;
    private String lastName;
    private String pan;
    private String emailId;
    private String mobile;
    private LocalDate dob;

    public UserDetailsDto(long id, String gender, Integer age, String tier, String firstName, String middleName, String lastName, String pan, String emailId, String mobile, LocalDate dob) {
        this.id = id;
        this.gender = gender;
        this.age = age;
        this.tier = tier;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.pan = pan;
        this.emailId = emailId;
        this.mobile = mobile;
        this.dob = dob;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getDob() {
        return Objects.nonNull(dob) ? dob.toString() : Constants.EMPTY;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }
}