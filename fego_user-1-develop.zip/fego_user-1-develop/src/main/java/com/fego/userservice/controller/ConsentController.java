package com.fego.userservice.controller;

import com.fego.foundation.common.response.SuccessResponse;
import com.fego.userservice.common.Constants;
import com.fego.userservice.dto.application.GenericResponseDto;
import com.fego.userservice.dto.integration.ConsentOtpResponseDto;
import com.fego.userservice.dto.integration.ConsentRequestDto;
import com.fego.userservice.service.ConsentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * Consent request and approve.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Api(tags = "Consent Controller")
@RestController
@RequestMapping("v1/consent")
public class ConsentController {

    private final ConsentService consentService;

    public ConsentController(ConsentService consentService) {
        this.consentService = consentService;
    }

    @Transactional
    @GetMapping("/request")
    @PreAuthorize("hasAuthority('CONSENT_REQUEST_PRIVILEGE')")
    @ApiOperation(value = "Raises a consent request to OneMoney for one year from the date of request")
    public SuccessResponse<ConsentOtpResponseDto> request(HttpServletRequest request) {
        return new SuccessResponse<>(
                consentService.requestConsentDetails(request.getHeader(Constants.AUTHORIZATION)), HttpStatus.OK);
    }

    @Transactional
    @PostMapping("/approve")
    @PreAuthorize("hasAuthority('CONSENT_APPROVE_PRIVILEGE')")
    @ApiOperation(value = "Verifies the OTP received for Consent request")
    public SuccessResponse<GenericResponseDto> approve(@RequestBody ConsentRequestDto consentRequestDto, HttpServletRequest request) {
        return new SuccessResponse<>(consentService.approveConsent(consentRequestDto, request.getHeader(Constants.AUTHORIZATION)), HttpStatus.OK);
    }
}