package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.dto.userengagement.SessionAuditDetailDto;
import com.fego.userservice.entity.SessionAudit;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * User session repository.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on July 27, 2021
 */
@Repository
public interface SessionAuditRepository extends BaseRepository<SessionAudit> {

    @Query(value = "select NEW com.fego.userservice.dto.userengagement.SessionAuditDetailDto (u.id,  u.userId, u.module, u.createdAt) FROM SessionAudit u where u.isDeleted=false and u.createdAt >= :startDateTimeStamp and u.createdAt <= :endDateTimeStamp and u.type = 'customer' AND u.module in (:modules) ")
    List<SessionAuditDetailDto> getSessionAuditDetails(@Param(value = "startDateTimeStamp") LocalDateTime startDateTimeStamp, @Param(value = "endDateTimeStamp") LocalDateTime endDateTimeStamp, @Param(value = "modules") List<String> modules);
}