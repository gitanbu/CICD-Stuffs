package com.fego.userservice.dto.integration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * <p>
 * Details of an user to get registered.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerRegistrationRequestDto {
    private String vua;
    private String name;
    private String phoneNumber;
    private Boolean termsAndConditions;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(Boolean termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public String getVua() {
        return vua;
    }

    public void setVua(String vua) {
        this.vua = vua;
    }
}