package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.entity.Permission;

/**
 * <p>
 * Repository for Permission Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public interface PermissionRepository extends BaseRepository<Permission> {
}