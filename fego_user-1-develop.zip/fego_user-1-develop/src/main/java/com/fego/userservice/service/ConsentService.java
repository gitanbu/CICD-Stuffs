package com.fego.userservice.service;

import com.fego.foundation.common.SecurityCommon;
import com.fego.foundation.common.utils.CacheUtil;
import com.fego.foundation.common.utils.CommonUtil;
import com.fego.foundation.common.utils.DateUtil;
import com.fego.foundation.common.utils.JsonUtil;
import com.fego.foundation.service.App2AppService;
import com.fego.foundation.service.CacheService;
import com.fego.userservice.common.Constants;
import com.fego.userservice.common.config.App2AppConfig;
import com.fego.userservice.common.enumeration.OnboardStatus;
import com.fego.userservice.dto.integration.ConsentApproveRequestDto;
import com.fego.userservice.dto.integration.ConsentOtpResponseDto;
import com.fego.userservice.dto.integration.ConsentRequestBodyDto;
import com.fego.userservice.dto.integration.ConsentRequestDto;
import com.fego.userservice.dto.integration.FiDataRangeDto;
import org.springframework.stereotype.Service;

/**
 * <p>
 * Implements the CRUD operation for the Consent.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Service
public class ConsentService {

    private static final String CONSENT_REQUEST = "consentRequest";
    private static final String TRANSACTION = "transaction";
    private static final String CONSENT_FROM = "consentFromDateRange";
    private static final String CONSENT_TO = "consentToDateRange";
    private final App2AppConfig app2AppConfig;
    private final CacheService cacheService;
    private final App2AppService app2AppService;
    private final UserService userService;

    public ConsentService(App2AppConfig app2AppConfig, CacheService cacheService, App2AppService app2AppService, UserService userService) {
        this.app2AppConfig = app2AppConfig;
        this.cacheService = cacheService;
        this.app2AppService = app2AppService;
        this.userService = userService;
    }

    /**
     * Raises a consent request to OneMoney for one year from the date of request.
     *
     * @param headerValue - Auth token.
     * @return consentOtpRefResponseDto - Otp for the Consent request.
     */
    public ConsentOtpResponseDto requestConsentDetails(String headerValue) {
        String fromDateRange = DateUtil.minusYear(DateUtil.convertUTCToLocalDate(), 1L) + Constants.START_OF_DAY;
        String toDateRange = DateUtil.minusDays(DateUtil.convertUTCToLocalDate(), 1L).plusYears(1) + Constants.END_OF_DAY;
        var consentRequestBodyDto = new ConsentRequestBodyDto();
        var fiDataRangeDto = new FiDataRangeDto();
        fiDataRangeDto.setFrom(fromDateRange);
        fiDataRangeDto.setTo(toDateRange);
        consentRequestBodyDto.setFiDataRange(fiDataRangeDto);
        String response = app2AppService.httpPost(CommonUtil.constructStringEmptySeparator(app2AppConfig.getIntegrationBaseUrl(), app2AppConfig.getIntegration().get(CONSENT_REQUEST)), app2AppService.setHeaders(App2AppService.formAuthorizationHeader(headerValue), consentRequestBodyDto));
        var object = JsonUtil.parseJsonResponse(response);
        var consentOtpResponseDto = JsonUtil.convertJsonIntoObject(object.toString(), ConsentOtpResponseDto.class);
        cacheService.save(SecurityCommon.getHashKey(), Constants.CONSENT_HANDLE, consentOtpResponseDto.getConsentHandle());
        cacheService.save(SecurityCommon.getHashKey(), CONSENT_FROM, fromDateRange);
        cacheService.save(SecurityCommon.getHashKey(), CONSENT_TO, toDateRange);
        return consentOtpResponseDto;
    }

    /**
     * Verifies the OTP received for Consent request. If Success transaction details of the linked accounts are retrieved.
     *
     * @param headerValue - Auth token.
     * @return consentOtpRefResponseDto - Success message if the entered OTP is correct.
     */
    public Object approveConsent(ConsentRequestDto consentApproveRequestDto, String headerValue) {
        var consentRequestDto = new ConsentApproveRequestDto();
        consentRequestDto.setConsentHandle(CacheUtil.getConsentHandle());
        consentRequestDto.setOtp(consentApproveRequestDto.getOtp());
        String response = app2AppService.httpPost(CommonUtil.constructStringEmptySeparator(app2AppConfig.getTransactionBaseUrl(), TRANSACTION), app2AppService.setHeaders(App2AppService.formAuthorizationHeader(headerValue), consentRequestDto));
        var object = JsonUtil.parseJsonResponse(response);
        var userDataDto = userService.findById(CacheUtil.getUserId());
        userDataDto.setOnboardingStatus(OnboardStatus.CONSENT_APPROVED);
        userService.patch(userDataDto);
        return JsonUtil.convertJsonIntoObject(object.toString(), Object.class);
    }
}