package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.entity.Widget;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Repository for Widget Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 19, 2021.
 */
@Repository
public interface WidgetRepository extends BaseRepository<Widget> {
}