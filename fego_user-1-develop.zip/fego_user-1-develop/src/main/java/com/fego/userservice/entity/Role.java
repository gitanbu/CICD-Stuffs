package com.fego.userservice.entity;

import com.fego.userservice.common.base.BaseModel;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * <p>
 * Holds Role of an user.
 * </p>
 *
 * @author Dinesh Easterline Kennedy created on March 9, 2021.
 */
@Entity
@Table
public class Role extends BaseModel {

    private String name;
    private String description;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}