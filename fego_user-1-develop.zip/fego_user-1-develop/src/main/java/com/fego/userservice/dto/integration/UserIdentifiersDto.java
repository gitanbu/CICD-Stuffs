package com.fego.userservice.dto.integration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>
 * User Identifiers.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on March 23, 2021.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserIdentifiersDto {

    private int id;
    @JsonProperty("user_identifier_type")
    private String userIdentifierType;
    @JsonProperty("user_identifier_value")
    private String userIdentifierValue;
    @JsonProperty("user_identifier_category")
    private String userIdentifierCategory;
    private String verificationStatus;
    private String fipId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserIdentifierType() {
        return userIdentifierType;
    }

    public void setUserIdentifierType(String userIdentifierType) {
        this.userIdentifierType = userIdentifierType;
    }

    public String getUserIdentifierValue() {
        return userIdentifierValue;
    }

    public void setUserIdentifierValue(String userIdentifierValue) {
        this.userIdentifierValue = userIdentifierValue;
    }

    public String getUserIdentifierCategory() {
        return userIdentifierCategory;
    }

    public void setUserIdentifierCategory(String userIdentifierCategory) {
        this.userIdentifierCategory = userIdentifierCategory;
    }

    public String getVerificationStatus() {
        return verificationStatus;
    }

    public void setVerificationStatus(String verificationStatus) {
        this.verificationStatus = verificationStatus;
    }

    public String getFipId() {
        return fipId;
    }

    public void setFipId(String fipId) {
        this.fipId = fipId;
    }
}