package com.fego.userservice.dto.userengagement;

import com.fego.userservice.common.enumeration.OnboardStatus;

import java.time.LocalDateTime;


public class FunnelDropOutDto {
    private Long id;
    private OnboardStatus onboardStatus;
    private LocalDateTime createdAt;

    public FunnelDropOutDto(Long id, OnboardStatus onboardStatus, LocalDateTime createdAt) {
        this.id = id;
        this.onboardStatus = onboardStatus;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OnboardStatus getOnboardStatus() {
        return onboardStatus;
    }

    public void setOnboardStatus(OnboardStatus onboardStatus) {
        this.onboardStatus = onboardStatus;
    }

    public String getCreatedAt() {
        return createdAt.toString();
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
