package com.fego.userservice.dto.userengagement;


import java.time.LocalDate;
import java.time.LocalDateTime;

public class UserSessionDetailDto {
    private Long id;
    private Long userId;
    private LocalDate accessDate;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Long duration;
    private String channel;

    public UserSessionDetailDto(Long id, Long userId, LocalDate accessDate, LocalDateTime startTime, LocalDateTime endTime, long duration, String channel) {
        this.id = id;
        this.userId = userId;
        this.accessDate = accessDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.duration = duration;
        this.channel = channel;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public LocalDate getAccessDate() {
        return accessDate;
    }

    public void setAccessDate(LocalDate accessDate) {
        this.accessDate = accessDate;
    }

    public String getStartTime() {
        return startTime.toString();
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime.toString();
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
