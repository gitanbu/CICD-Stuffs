package com.fego.userservice.service;

import com.fego.foundation.common.config.interceptor.TenantContext;
import com.fego.foundation.common.utils.CacheUtil;
import com.fego.foundation.common.utils.CommonUtil;
import com.fego.foundation.common.utils.DateUtil;
import com.fego.foundation.common.utils.JsonUtil;
import com.fego.foundation.service.App2AppService;
import com.fego.foundation.service.CacheService;
import com.fego.userservice.common.Constants;
import com.fego.userservice.common.config.App2AppConfig;
import com.fego.userservice.dto.application.UserDataDto;
import com.fego.userservice.dto.application.UserSessionDto;
import com.fego.userservice.dto.integration.LoginDto;
import com.fego.userservice.dto.integration.LoginVerifyDto;
import com.fego.userservice.dto.integration.LoginVerifyResponseDto;
import com.fego.userservice.dto.security.UserDto;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Objects;

import static com.fego.foundation.common.Constants.IS_ALREADY_LOGGED_IN;

/**
 * <p>
 * Implements the User login and verify.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Service
public class LoginService {

    private static final String LOGIN_GET_OTP = "loginGetOTP";
    private static final String LOGIN_VERIFY_OTP = "loginVerifyOTP";
    private static final String CURRENT_DEVICE = "currentDevice";
    private static final String USER_SESSION_ID = "userSessionId";
    private final App2AppConfig app2AppConfig;
    private final CacheService cacheService;
    private final UserService userService;
    private final App2AppService app2AppService;
    private final TenantService tenantService;
    private final UserSessionService userSessionService;

    public LoginService(App2AppConfig app2AppConfig, CacheService cacheService, UserService userService, App2AppService app2AppService, TenantService tenantService, UserSessionService userSessionService) {
        this.app2AppConfig = app2AppConfig;
        this.cacheService = cacheService;
        this.userService = userService;
        this.app2AppService = app2AppService;
        this.tenantService = tenantService;
        this.userSessionService = userSessionService;
    }

    /**
     * Returns OTP for the entered mobile number.
     *
     * @param loginDto - Phone Number of the user.
     * @return Object - OTP to user.
     */
    public Object login(LoginDto loginDto) {
        String response = app2AppService.httpPost(CommonUtil.constructStringEmptySeparator(app2AppConfig.getIntegrationBaseUrl(), app2AppConfig.getIntegration().get(LOGIN_GET_OTP)), new HttpEntity<>(loginDto));
        var object = JsonUtil.parseJsonResponse(response);
        return JsonUtil.convertJsonIntoObject(object.toString(), Object.class);
    }

    /**
     * Verifies the OTP received for login.
     *
     * @param loginVerifyDto - OTP received for login.
     * @return Object - Success message if the login is successful.
     */
    public UserDto verifyOtp(LoginVerifyDto loginVerifyDto, HttpServletRequest httpServletRequest) {
        String response = app2AppService.httpPost(CommonUtil.constructStringEmptySeparator(app2AppConfig.getIntegrationBaseUrl(), app2AppConfig.getIntegration().get(
                        LOGIN_VERIFY_OTP)),
                new HttpEntity<>(loginVerifyDto));
        var object = JsonUtil.parseJsonResponse(response);
        var loginVerifyResponseDto = JsonUtil.convertJsonIntoObject(object.toString(), LoginVerifyResponseDto.class);
        var userDataDto = userService.findByMobile(loginVerifyDto.getPhoneNumber());
        var tenantDto = tenantService.findByTenantName(TenantContext.getTenantId());
        String hashKey = userDataDto.getId() + Constants.UNDERSCORE + userDataDto.getMobile();
        if (Objects.nonNull(CacheUtil.getUserSessionId(hashKey))) {
            userService.updateUserSession(CacheUtil.getUserSessionId(hashKey));
        }
        var isAlreadyLoggedIn = cacheService.delete(hashKey);
        cacheService.save(hashKey, IS_ALREADY_LOGGED_IN, isAlreadyLoggedIn);
        cacheService.save(hashKey, Constants.USER_ID, userDataDto.getId());
        cacheService.save(hashKey, Constants.SESSION_ID, loginVerifyResponseDto.getSessionId());
        cacheService.save(hashKey, Constants.IS_LOGGED_IN, Boolean.TRUE);
        cacheService.save(hashKey, Constants.MOBILE, loginVerifyDto.getPhoneNumber());
        cacheService.save(hashKey, Constants.TIME_ZONE, userDataDto.getTimeZone());
        cacheService.save(hashKey, Constants.IS_DATA_CATEGORIZATION_SUBSCRIBED, tenantDto.getDataCategorizationSubscribed());
        var userSessionDto = getUserSessionDto(httpServletRequest, userDataDto);
        var userSession = userSessionService.add(userSessionDto);
        cacheService.save(hashKey, USER_SESSION_ID, userSession.getId());
        return userService.getUserDto(userDataDto, Boolean.FALSE, userSession.getId());
    }

    /**
     * Forms User session dto from user and device details.
     *
     * @param httpServletRequest - HttpServletRequest details.
     * @param userDataDto        - User Details
     * @return Object - Success message if the login is successful.
     */
    private UserSessionDto getUserSessionDto(HttpServletRequest httpServletRequest, UserDataDto userDataDto) {
        var userSessionDto = new UserSessionDto();
        userSessionDto.setUserId(userDataDto.getId());
        userSessionDto.setAccessDate(DateUtil.currentDate());
        userSessionDto.setStartTime(LocalDateTime.now());
        userSessionDto.setChannel(httpServletRequest.getHeader(CURRENT_DEVICE));
        return userSessionDto;
    }
}
