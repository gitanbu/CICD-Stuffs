package com.fego.userservice.dto.application;

/**
 * <p>
 * Holds the details of Partner Login.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on June 01, 2021
 */
public class PartnerLoginRequestDto {
    private String email;
    private String password;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
