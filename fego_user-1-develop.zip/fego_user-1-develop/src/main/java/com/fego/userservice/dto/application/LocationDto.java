package com.fego.userservice.dto.application;

import com.fego.userservice.common.base.BaseDto;

import java.math.BigDecimal;

/**
 * <p>
 * Location and its respective Tier, Latitude & Longitude details.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public class LocationDto extends BaseDto {

    private String locationName;
    private String tier;
    private BigDecimal latitude;
    private BigDecimal longitude;

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }
}