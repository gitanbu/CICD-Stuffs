package com.fego.userservice.dto.security;

import java.util.List;

/**
 * <p>
 * Role details.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on March 23, 2021.
 */
public class RoleDto {

    private long id;
    private String name;
    private String description;
    private boolean isDeleted;
    private List<PermissionDto> permissions;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public List<PermissionDto> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<PermissionDto> permissions) {
        this.permissions = permissions;
    }
}