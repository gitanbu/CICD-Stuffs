package com.fego.userservice;

import com.fego.userservice.common.base.BaseRepositoryImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * <p>
 * Main class.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@SpringBootApplication(scanBasePackages = "com.fego")
@EnableJpaRepositories(repositoryBaseClass = BaseRepositoryImpl.class)
public class FegoUserApplication {

    private static final Logger logger = LoggerFactory.getLogger(FegoUserApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(FegoUserApplication.class, args);
        logger.info("Fego User Service has been started.");
    }
}
