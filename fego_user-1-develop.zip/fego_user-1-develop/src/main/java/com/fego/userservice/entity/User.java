package com.fego.userservice.entity;

import com.fego.userservice.common.base.BaseModel;
import com.fego.userservice.common.enumeration.OnboardStatus;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * Holds details of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Entity
@Table(name = "\"user\"")
public class User extends BaseModel {

    private String firstName;
    private String middleName;
    private String lastName;
    @NotNull
    private String mobile;
    private Boolean termsAndConditions;
    private Boolean isKycVerified;
    @NotNull
    private String emailId;
    private long addressId;
    private String pan;
    private LocalDate dob;
    private Integer age;
    private String gender;
    private String tier;
    private String type;
    private Boolean isOtp;
    private String vua;
    private String image;
    private Integer savingPreference;
    private String tenant;
    @Enumerated(EnumType.STRING)
    private OnboardStatus onboardStatus;
    private String forgetPasswordKey;
    @NotNull
    private String password;
    private String userType;
    private Boolean isPartnerLoggedIn;
    private String timeZone;
    private Boolean isBatchUser;
    private LocalDateTime verificationTokenSentTime;
    private Boolean accountLocked;
    private Integer failureAttempts;
    private LocalDateTime lockTime;
    private LocalDateTime passwordChangedTime;
    private String oldPassword;

    public LocalDateTime getVerificationTokenSentTime() {
        return verificationTokenSentTime;
    }

    public void setVerificationTokenSentTime(LocalDateTime verificationTokenSentTime) {
        this.verificationTokenSentTime = verificationTokenSentTime;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Boolean getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(Boolean termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public Boolean getKycVerified() {
        return isKycVerified;
    }

    public void setKycVerified(Boolean kycVerified) {
        isKycVerified = kycVerified;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public long getAddressId() {
        return addressId;
    }

    public void setAddressId(long addressId) {
        this.addressId = addressId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getOtp() {
        return isOtp;
    }

    public void setOtp(Boolean otp) {
        isOtp = otp;
    }

    public String getVua() {
        return vua;
    }

    public void setVua(String vua) {
        this.vua = vua;
    }

    public Integer getSavingPreference() {
        return savingPreference;
    }

    public void setSavingPreference(Integer savingPreference) {
        this.savingPreference = savingPreference;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTier() {
        return tier;
    }

    public void setTier(String tier) {
        this.tier = tier;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public OnboardStatus getOnboardingStatus() {
        return onboardStatus;
    }

    public void setOnboardingStatus(OnboardStatus onboardStatus) {
        this.onboardStatus = onboardStatus;
    }

    public String getForgetPasswordKey() {
        return forgetPasswordKey;
    }

    public void setForgetPasswordKey(String forgetPasswordKey) {
        this.forgetPasswordKey = forgetPasswordKey;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public Boolean getPartnerLoggedIn() {
        return isPartnerLoggedIn;
    }

    public void setPartnerLoggedIn(Boolean isPartnerLoggedIn) {
        this.isPartnerLoggedIn = isPartnerLoggedIn;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public Boolean getBatchUser() {
        return isBatchUser;
    }

    public void setBatchUser(Boolean batchUser) {
        isBatchUser = batchUser;
    }

    public Boolean getAccountLocked() {
        return accountLocked;
    }

    public void setAccountLocked(Boolean accountLocked) {
        this.accountLocked = accountLocked;
    }

    public Integer getFailureAttempts() {
        return failureAttempts;
    }

    public void setFailureAttempts(Integer failureAttempts) {
        this.failureAttempts = failureAttempts;
    }

    public LocalDateTime getLockTime() {
        return lockTime;
    }

    public void setLockTime(LocalDateTime lockTime) {
        this.lockTime = lockTime;
    }

    public LocalDateTime getPasswordChangedTime() {
        return passwordChangedTime;
    }

    public void setPasswordChangedTime(LocalDateTime passwordChangedTime) {
        this.passwordChangedTime = passwordChangedTime;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }
}
