package com.fego.userservice.common.base;

/**
 * <p>
 * Base Task for executing task after a CRUD operation.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public interface BaseTask<M extends BaseModel> {
    void onCreate(M model);

    void onUpdate(M model);

    void onDelete(M model);
}