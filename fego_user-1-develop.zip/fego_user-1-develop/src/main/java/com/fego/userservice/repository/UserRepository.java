package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.dto.application.UserDetailsDto;
import com.fego.userservice.dto.userengagement.FunnelDropOutDto;
import com.fego.userservice.entity.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * Repository for User Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Repository
public interface UserRepository extends BaseRepository<User> {
    @Query(value = "select NEW com.fego.userservice.dto.application.UserDetailsDto (u.id, u.gender, u.age, u.tier, u.firstName, u.middleName, u.lastName, u.pan, u.emailId, u.mobile, u.dob) FROM User u where u.isDeleted=false and u.isBatchUser = false and u.userType = 'customer' and u.onboardStatus = 'REGISTRATION_COMPLETED'")
    List<UserDetailsDto> getUserDetailsForBatch();

    @Query(value = "select NEW com.fego.userservice.dto.application.UserDetailsDto (u.id, u.gender, u.age, u.tier, u.firstName, u.middleName, u.lastName, u.pan, u.emailId, u.mobile, u.dob) FROM User u where u.isDeleted=false and u.isBatchUser = false and u.id = :id and u.userType = 'customer'")
    UserDetailsDto getUserDetailsForOnboard(@Param(value = "id") long id);

    @Query(value = "select NEW com.fego.userservice.dto.userengagement.FunnelDropOutDto (u.id,  u.onboardStatus, u.createdAt) FROM User u where u.isDeleted=false and u.isBatchUser = false and u.createdAt >= :startDateTimeStamp and u.createdAt <= :endDateTimeStamp   and u.userType = 'customer'")
    List<FunnelDropOutDto> getFunnelDropOutUserDetails(@Param(value = "startDateTimeStamp") LocalDateTime startDateTimeStamp, @Param(value = "endDateTimeStamp") LocalDateTime endDateTimeStamp);

}
