package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.entity.Location;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Repository for Location entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Repository
public interface LocationRepository extends BaseRepository<Location> {
}