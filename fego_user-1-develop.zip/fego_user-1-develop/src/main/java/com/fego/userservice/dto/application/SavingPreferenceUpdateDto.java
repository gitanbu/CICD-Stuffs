package com.fego.userservice.dto.application;

/**
 * <p>
 * Details to updated Saving Preference of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public class SavingPreferenceUpdateDto {
    private String savingPreference;

    public String getSavingPreference() {
        return savingPreference;
    }

    public void setSavingPreference(String savingPreference) {
        this.savingPreference = savingPreference;
    }
}