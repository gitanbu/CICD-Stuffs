package com.fego.userservice.service;

import com.fego.foundation.aws.storage.AwsStorageConfig;
import com.fego.foundation.aws.storage.AwsStorageService;
import com.fego.foundation.common.SecurityCommon;
import com.fego.foundation.common.config.ResponseMessage;
import com.fego.foundation.common.config.interceptor.TenantContext;
import com.fego.foundation.common.enumeration.ErrorCode;
import com.fego.foundation.common.utils.CacheUtil;
import com.fego.foundation.common.utils.CommonUtil;
import com.fego.foundation.common.utils.DateUtil;
import com.fego.foundation.common.utils.JsonUtil;
import com.fego.foundation.exception.BadRequestException;
import com.fego.foundation.exception.FegoAuthenticationException;
import com.fego.foundation.exception.InvalidDataException;
import com.fego.foundation.exception.RecordNotFoundException;
import com.fego.foundation.exception.SavingPreferenceException;
import com.fego.foundation.exception.UserExistException;
import com.fego.foundation.service.App2AppService;
import com.fego.foundation.service.CacheService;
import com.fego.foundation.service.EmailService;
import com.fego.userservice.common.Constants;
import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.common.base.BaseService;
import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.common.config.App2AppConfig;
import com.fego.userservice.common.enumeration.OnboardStatus;
import com.fego.userservice.common.enumeration.SavingPreference;
import com.fego.userservice.dto.application.AccountAddressDto;
import com.fego.userservice.dto.application.AddressDetailsDto;
import com.fego.userservice.dto.application.AddressDto;
import com.fego.userservice.dto.application.GenericResponseDto;
import com.fego.userservice.dto.application.PartnerDto;
import com.fego.userservice.dto.application.PartnerLoginRequestDto;
import com.fego.userservice.dto.application.ResetPasswordDto;
import com.fego.userservice.dto.application.SavingPreferenceUpdateDto;
import com.fego.userservice.dto.application.SessionAuditDto;
import com.fego.userservice.dto.application.UserDataDto;
import com.fego.userservice.dto.application.UserDetailsDto;
import com.fego.userservice.dto.application.UserProfileDetailDto;
import com.fego.userservice.dto.application.UserProfileDto;
import com.fego.userservice.dto.application.UserSessionDto;
import com.fego.userservice.dto.integration.CustomerRegistrationRequestDto;
import com.fego.userservice.dto.integration.CustomerRegistrationVerifyDto;
import com.fego.userservice.dto.integration.HoldersDto;
import com.fego.userservice.dto.integration.ProfileResponseDto;
import com.fego.userservice.dto.security.UserDto;
import com.fego.userservice.dto.userengagement.FunnelDropOutDto;
import com.fego.userservice.entity.Location;
import com.fego.userservice.entity.SessionAudit;
import com.fego.userservice.entity.User;
import com.fego.userservice.entity.UserRole;
import com.fego.userservice.entity.UserSession;
import com.fego.userservice.repository.AddressRepository;
import com.fego.userservice.repository.LocationRepository;
import com.fego.userservice.repository.UserRepository;
import com.fego.userservice.repository.UserRoleRepository;
import com.fego.userservice.task.UserTask;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.fego.foundation.common.Constants.IS_ALREADY_LOGGED_IN;
import static com.fego.foundation.common.Constants.PROFILE_FOLDER;

/**
 * <p>
 * Implements the CRUD operation of an user.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Service
public class UserService extends BaseService<User, UserDataDto, UserTask> {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
    private static final String OTP_VERIFY = "otpVerify";
    private static final String OTP_SEND = "otpSend";
    private static final String CUSTOMER_VUA = "customerVua";
    private static final String CANNOT_FIND_THE_USER = "Cannot find the user.";
    private static final String PASSWORD_SAME_AS_OLD_PASSWORD_MESSAGE = "New password cannot be same as your old password.";
    private static final String PASSWORD_SAME_AS_PREVIOUS_FOUR_PASSWORD_MESSAGE = "New password cannot be same as your old password.";
    private static final String PASSWORD_SAME_AS_USERNAME_MESSAGE = "New password cannot be same as your username.";
    private static final String PASSWORD_POLICY_REQUIREMENT_MESSAGE = "The password you entered doesn't meet password policy requirement. Try one that's longer or more complex.";
    private static final String OLD_PASSWORD_INCORRECT_MESSAGE = "The old password you have entered is incorrect";
    private static final String ACCOUNT_LOCKED_MESSAGE = "Your Account has been locked due to 3 failed attempts. It will be unlocked after 24 hours.";
    private static final String LOGIN_FAILED_MESSAGE = "Login failed. Invalid email or password";
    private static final String PARTNER_EMAIL = "partnerEmail";
    private static final String SUPPORT_EMAIL = "contact@fego.ai";
    private final App2AppConfig app2AppConfig;
    private final AwsStorageConfig awsStorageConfig;
    private final AddressService addressService;
    private final UserRepository userRepository;
    private final CacheService cacheService;
    private final App2AppService app2AppService;
    private final EmailService emailService;
    private final UserRoleRepository userRoleRepository;
    private final RoleService roleService;
    private final ResponseMessage responseMessage;
    private final AwsStorageService awsStorageService;
    private final IdSpecifications<Location> locationIdSpecifications;
    private final IdSpecifications<UserSession> userSessionIdSpecifications;
    private final IdSpecifications<SessionAudit> sessionAuditSpecifications;
    private final IdSpecifications<User> userSpecifications;
    private final LocationRepository locationRepository;
    private final AddressRepository addressRepository;
    private final TenantService tenantService;
    private final UserSessionService userSessionService;
    private final SessionAuditService sessionAuditService;

    public UserService(UserRepository userRepository, BaseMapper<User, UserDataDto> userMapper, IdSpecifications<User> userIdSpecifications, App2AppConfig app2AppConfig,
                       BaseTask<User> userTask, AwsStorageConfig awsStorageConfig, AddressService addressService, CacheService cacheService, App2AppService app2AppService, EmailService emailService, UserRoleRepository userRoleRepository, RoleService roleService, ResponseMessage responseMessage, AwsStorageService awsStorageService, IdSpecifications<Location> locationIdSpecifications, IdSpecifications<UserSession> userSessionIdSpecifications, IdSpecifications<User> userSpecifications, LocationRepository locationRepository, AddressRepository addressRepository, TenantService tenantService, UserSessionService userSessionService, SessionAuditService sessionAuditService, IdSpecifications<SessionAudit> sessionAuditSpecifications) {
        super(userRepository, userMapper, userIdSpecifications, userTask);
        this.app2AppConfig = app2AppConfig;
        this.awsStorageConfig = awsStorageConfig;
        this.addressService = addressService;
        this.userRepository = userRepository;
        this.cacheService = cacheService;
        this.app2AppService = app2AppService;
        this.emailService = emailService;
        this.userRoleRepository = userRoleRepository;
        this.roleService = roleService;
        this.responseMessage = responseMessage;
        this.awsStorageService = awsStorageService;
        this.locationIdSpecifications = locationIdSpecifications;
        this.userSessionIdSpecifications = userSessionIdSpecifications;
        this.userSpecifications = userSpecifications;
        this.locationRepository = locationRepository;
        this.addressRepository = addressRepository;
        this.tenantService = tenantService;
        this.userSessionService = userSessionService;
        this.sessionAuditService = sessionAuditService;
        this.sessionAuditSpecifications = sessionAuditSpecifications;
    }

    /**
     * Returns OTP for the entered mobile number.
     *
     * @param customerRegistrationRequestDto - Details of the User.
     * @return Object - If not already registered, OTP is sent to user mobile.
     */
    public Object getOtpReference(CustomerRegistrationRequestDto customerRegistrationRequestDto) {
        String response = app2AppService.httpPost(CommonUtil.constructStringEmptySeparator(app2AppConfig.getIntegrationBaseUrl(), app2AppConfig.getIntegration().get(OTP_SEND)), new HttpEntity<>(customerRegistrationRequestDto));
        var object = JsonUtil.parseJsonResponse(response);
        return JsonUtil.convertJsonIntoObject(object.toString(), Object.class);
    }

    /**
     * Verifies the OTP received for registration.
     *
     * @param customerRegistrationVerifyDto - OTP entered by user.
     * @return Object - A Success message if the user is registered properly.
     */
    public Object verifyOtp(CustomerRegistrationVerifyDto customerRegistrationVerifyDto) {
        String otpResponse = app2AppService.httpPost(CommonUtil.constructStringEmptySeparator(app2AppConfig.getIntegrationBaseUrl(), app2AppConfig.getIntegration().get(OTP_VERIFY)), new HttpEntity<>(customerRegistrationVerifyDto));
        var profileResponse = JsonUtil.parseJsonResponse(otpResponse);
        var profileResponseDto = JsonUtil.convertJsonIntoObject(profileResponse.toString(), ProfileResponseDto.class);
        var userDto = profileResponseDto.getUserData();
        userDto.setUserType("customer");
        userDto.setTimeZone("Asia/Kolkata");
        userDto.setOnboardingStatus(OnboardStatus.ONBOARDED);
        userDto.setPartnerLoggedIn(Boolean.FALSE);
        userDto.setPassword(Constants.EMPTY);
        userDto.setBatchUser(Boolean.FALSE);
        var userDataDto = add(userDto);
        saveUserRole(userDataDto, Boolean.TRUE);
        var tenantDto = tenantService.findByTenantName(TenantContext.getTenantId());
        String hashKey = userDataDto.getId() + Constants.UNDERSCORE + userDataDto.getMobile();
        var isAlreadyLoggedIn = cacheService.delete(hashKey);
        cacheService.save(hashKey, IS_ALREADY_LOGGED_IN, isAlreadyLoggedIn);
        saveCacheValues(profileResponseDto, userDataDto, tenantDto.getDataCategorizationSubscribed(), hashKey);
        return getUserDto(userDataDto, Boolean.FALSE, 0L);
    }

    /**
     * Saves the User Role.
     *
     * @param userDataDto - User Details
     */
    private void saveUserRole(UserDataDto userDataDto, boolean isCustomer) {
        var userRole = new UserRole();
        userRole.setUserId(userDataDto.getId());
        userRole.setRoleId(isCustomer ? 1L : 2L);
        userRole.setCreatedBy(userDataDto.getId());
        userRole.setUpdatedBy(userDataDto.getId());
        userRoleRepository.save(userRole);
        logger.info("User Role has been saved in the table");
    }

    /**
     * Save the cache values after successful on-boarding.
     *
     * @param profileResponseDto             - Session Id from Integration service.
     * @param userDataDto                    - User Details
     * @param isDataCategorizationSubscribed - Boolean value whether categorization is subscribed (or) not.
     * @param hashKey                        - Hash key for redis cache.
     */
    private void saveCacheValues(ProfileResponseDto profileResponseDto, UserDataDto userDataDto, boolean isDataCategorizationSubscribed, String hashKey) {
        cacheService.save(hashKey, Constants.USER_ID, userDataDto.getId());
        cacheService.save(hashKey, Constants.IS_LOGGED_IN, Boolean.TRUE);
        cacheService.save(hashKey, CUSTOMER_VUA, userDataDto.getVua());
        cacheService.save(hashKey, Constants.MOBILE, userDataDto.getMobile());
        cacheService.save(hashKey, Constants.SESSION_ID, profileResponseDto.getSessionId());
        cacheService.save(hashKey, Constants.TIME_ZONE, userDataDto.getTimeZone());
        cacheService.save(hashKey, Constants.IS_DATA_CATEGORIZATION_SUBSCRIBED, isDataCategorizationSubscribed);
        logger.info("Cache values are saved");
    }

    /**
     * Prepares UserDto based on UserDataDto for the Authorization.
     *
     * @param userDataDto - User Details
     * @return userDto - Details required for Authorization.
     */
    public UserDto getUserDto(UserDataDto userDataDto, Boolean isChangePasswordRequired, Long sessionId) {
        var userDto = new UserDto();
        userDto.setId(userDataDto.getId());
        userDto.setMobile(userDataDto.getMobile());
        userDto.setOnboardStatus(userDataDto.getOnboardingStatus().name());
        userDto.setTenant(userDataDto.getTenant());
        userDto.setUserType(userDataDto.getUserType());
        userDto.setIsDeleted(userDataDto.getIsDeleted());
        userDto.setFirstName(userDataDto.getFirstName());
        userDto.setRoles(roleService.getRoleByUserId(userDataDto.getId()));
        userDto.setPartnerAccountLoggedIn(userDataDto.getPartnerLoggedIn());
        userDto.setEmail(Objects.nonNull(userDataDto.getEmail()) ? userDataDto.getEmail() : Constants.EMPTY);
        userDto.setTimeZone(userDataDto.getTimeZone());
        userDto.setChangePasswordRequired(isChangePasswordRequired);
        userDto.setSessionId(sessionId);
        return userDto;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doPatch(User incomingUser, User toUpdateUser) {
        if (Objects.nonNull(incomingUser.getOnboardingStatus())) {
            toUpdateUser.setOnboardingStatus(incomingUser.getOnboardingStatus());
        }
        if (Objects.nonNull(incomingUser.getSavingPreference())) {
            toUpdateUser.setSavingPreference(incomingUser.getSavingPreference());
        }
        if (Objects.nonNull(incomingUser.getFirstName())) {
            toUpdateUser.setFirstName(incomingUser.getFirstName());
        }
        if (Objects.nonNull(incomingUser.getDob())) {
            toUpdateUser.setDob(incomingUser.getDob());
        }
        if (Objects.nonNull(incomingUser.getEmailId())) {
            toUpdateUser.setEmailId(incomingUser.getEmailId());
        }
        if (Objects.nonNull(incomingUser.getPan())) {
            toUpdateUser.setPan(incomingUser.getPan());
        }
        if (Objects.nonNull(incomingUser.getKycVerified())) {
            toUpdateUser.setKycVerified(incomingUser.getKycVerified());
        }
        if (Objects.nonNull(incomingUser.getType())) {
            toUpdateUser.setType(incomingUser.getType());
        }
        if (Objects.nonNull(incomingUser.getAge())) {
            toUpdateUser.setAge(incomingUser.getAge());
        }
        if (Objects.nonNull(incomingUser.getGender())) {
            toUpdateUser.setGender(incomingUser.getGender());
        }
        if (Objects.nonNull(incomingUser.getTier())) {
            toUpdateUser.setTier(incomingUser.getTier());
        }
        if (Objects.nonNull(incomingUser.getPassword())) {
            toUpdateUser.setPassword(incomingUser.getPassword());
        }
        if (Objects.nonNull(incomingUser.getPartnerLoggedIn())) {
            toUpdateUser.setPartnerLoggedIn(incomingUser.getPartnerLoggedIn());
        }
        if (Objects.nonNull(incomingUser.getVerificationTokenSentTime())) {
            toUpdateUser.setVerificationTokenSentTime(incomingUser.getVerificationTokenSentTime());
        }
        if (Objects.nonNull(incomingUser.getAccountLocked())) {
            toUpdateUser.setAccountLocked(incomingUser.getAccountLocked());
        }
        if (Objects.nonNull(incomingUser.getFailureAttempts())) {
            toUpdateUser.setFailureAttempts(incomingUser.getFailureAttempts());
        }
        if (Objects.nonNull(incomingUser.getLockTime())) {
            toUpdateUser.setLockTime(incomingUser.getLockTime());
        }
        if (Objects.nonNull(incomingUser.getPasswordChangedTime())) {
            toUpdateUser.setPasswordChangedTime(incomingUser.getPasswordChangedTime());
        }
        if (Objects.nonNull(incomingUser.getOldPassword())) {
            toUpdateUser.setOldPassword(incomingUser.getOldPassword());
        }
        toUpdateUser.setForgetPasswordKey(incomingUser.getForgetPasswordKey());
        toUpdateUser.setImage(incomingUser.getImage());
        toUpdateUser.setAddressId(incomingUser.getAddressId());
        toUpdateUser.setCreatedBy(incomingUser.getCreatedBy());
        toUpdateUser.setUpdatedBy(incomingUser.getUpdatedBy());
    }

    /**
     * Update the Address Id in User table.
     *
     * @param userId - User ID.
     */
    private void updateUser(long userId) {
        var userDto = findById(userId);
        var addressDto = addressService.findByRecentAddress(userId);
        userDto.setAddressId(addressDto.getId());
        userDto.setTier(addressDto.getTier());
        patch(userDto);
        logger.info("User has been updated in the table");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateAdd(UserDataDto userData) {
        String tenant = TenantContext.getTenantId();
        userData.setTenant(tenant);
        userData.setIsOtp(Boolean.TRUE);
    }

    /**
     * Update the Saving Preference of a user.
     *
     * @param savingPreferenceUpdateDto - The respective Saving Preference value.
     * @return successResponseDto - Success message if Saving Preference has been updated.
     */
    public GenericResponseDto updateSavingPreference(SavingPreferenceUpdateDto savingPreferenceUpdateDto) {
        var userDto = findById(CacheUtil.getUserId());
        userDto.setSavingPreference(SavingPreference.valueOf(savingPreferenceUpdateDto.getSavingPreference()).code());
        userDto.setOnboardingStatus(OnboardStatus.REGISTRATION_COMPLETED);
        patch(userDto);
        var genericResponseDto = new GenericResponseDto();
        genericResponseDto.setStatus(Constants.SUCCESS);
        return genericResponseDto;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validatePatch(UserDataDto incomingDto) {
        incomingDto.setCreatedBy(incomingDto.getId());
        incomingDto.setUpdatedBy(incomingDto.getId());
    }

    /**
     * Returns Saving Preference of a user.
     *
     * @return Integer - Integer value of Saving Preference.
     * @throws SavingPreferenceException When the User has not updated the Saving Preference.
     */
    public Integer fetchSavingPreference() {
        var userDto = findById(CacheUtil.getUserId());
        if (Objects.isNull(userDto.getSavingPreference())) {
            throw new SavingPreferenceException(ErrorCode.SAVING_PREFERENCE_NOT_UPDATED, responseMessage.getErrorMessage(ErrorCode.SAVING_PREFERENCE_NOT_UPDATED));
        }
        return userDto.getSavingPreference();
    }

    /**
     * Updates User Details of a User with the details received from OneMoney.
     *
     * @return successResponseDto - Success message if the username has been updated properly.
     */
    public GenericResponseDto updateUserName(String userName) {
        var userDto = findById(CacheUtil.getUserId());
        userDto.setFirstName(userName);
        patch(userDto);
        var genericResponseDto = new GenericResponseDto();
        genericResponseDto.setStatus(Constants.SUCCESS);
        return genericResponseDto;
    }

    public List<AddressDetailsDto> getUserAddress() {
        return addressRepository.getUserAddressDetails();
    }

    /**
     * Fetch the Details of all users which are in active status.
     *
     * @return List<UserDetailsDto> - List of User Details.
     */
    public List<UserDetailsDto> getUserDetailsForBatch() {
        return userRepository.getUserDetailsForBatch();
    }

    public UserDetailsDto getUserDetailsForOnboard(long id) {
        return userRepository.getUserDetailsForOnboard(id);
    }

    /**
     * Method to fetch last two month data from user table.
     *
     * @return List<FunnelDropOutDto> - List contains last two months data from user table.
     */
    public List<FunnelDropOutDto> getFunnelDropOutUserDetails() {
        LocalDate currentDate = DateUtil.currentDate();
        LocalDateTime lastMonthEndDate = DateUtil.minusMonthsFromLastDay(currentDate, 1).atTime(LocalTime.MAX);
        LocalDateTime lastMonthStartDate = DateUtil.minusMonthsFromFirstDay(currentDate, 1).atTime(LocalTime.MIN);
        return userRepository.getFunnelDropOutUserDetails(lastMonthStartDate, lastMonthEndDate);
    }

    /**
     * Updates User Details of a User with the details received from OneMoney.
     *
     * @param userId  - The respective User Id.
     * @param holders - Details of the User received from OneMoney.
     * @return successResponseDto - Success message if the user details has been updated properly.
     */
    public GenericResponseDto updateUserDetails(long userId, List<HoldersDto> holders) {
        var holder = holders.get(0).getHolderDto();
        var userDto = findById(userId);
        userDto.setDob(holder.getDob());
        userDto.setGender("MALE"); // change once original value received from OneMoney. As of now Gender is not received from OneMoney.
        userDto.setPan(holder.getPan());
        userDto.setAge(Period.between(holder.getDob(), DateUtil.convertUTCToLocalDate()).getYears());
        userDto.setEmail(holder.getEmail());
        if (Objects.nonNull(holder.getCkycCompliance())) {
            userDto.setIsKycVerified(holder.getCkycCompliance().equalsIgnoreCase(Constants.TRUE_VALUE));
        }
        userDto.setType(holders.get(0).getType());
        patch(userDto);
        logger.info("User Details has been updated in the Database.");
        var genericResponseDto = new GenericResponseDto();
        genericResponseDto.setStatus(Constants.SUCCESS);
        return genericResponseDto;
    }

    /**
     * Updates Address of a User with the details received from OneMoney.
     *
     * @param accountAddressDto - Details of the User received from OneMoney.
     */
    public GenericResponseDto updateUserAddress(List<AccountAddressDto> accountAddressDto) {
        accountAddressDto.forEach(address -> {
            var existingAddressDto = addressService.findAddressByAccountId(address.getAccountId());
            if (Objects.nonNull(existingAddressDto)) {
                formAddressDto(address, existingAddressDto);
                addressService.patch(existingAddressDto);
            } else {
                var addressDto = new AddressDto();
                formAddressDto(address, addressDto);
                addressService.add(addressDto);
            }
        });
        logger.info("User Address has been updated in the Database.");
        updateUser(accountAddressDto.get(0).getUserId());
        var genericResponseDto = new GenericResponseDto();
        genericResponseDto.setStatus(Constants.SUCCESS);
        return genericResponseDto;
    }

    /**
     * Returns details of all Locations.
     *
     * @param city - City name for which the Tier, Latitude and Longitude details will be retrieved.
     * @return locationDetails - Returns the Tier, Latitude and Longitude details for every location.
     */
    private Map<String, List<Location>> findLocationDetails(String city) {
        Specification<Location> locationSpecification = locationIdSpecifications.getLocationDetails(city);
        Optional<Location> allLocations = locationRepository.findOne(locationSpecification);
        Map<String, List<Location>> locationDetails = new HashMap<>();
        if (allLocations.isPresent()) {
            locationDetails = allLocations.stream().collect(Collectors.groupingBy(Location::getLocationName, Collectors.toList()));
        }
        return locationDetails;
    }

    /**
     * Forms addressDto from the values received from Account Aggregator.
     *
     * @param addressDto - The target dto in which details need to be filled.
     * @param address    - Dto received from Account Aggregator.
     */
    private void formAddressDto(AccountAddressDto address, AddressDto addressDto) {
        String customerAddress = address.getHoldersDto().getHolderDto().getAddress();
        addressDto.setStreetOne(customerAddress);
        addressDto.setRecent(address.getRecentAddress());
        addressDto.setAccountId(address.getAccountId());
        addressDto.setUserId(address.getUserId());
        var city = customerAddress.substring(customerAddress.lastIndexOf(Constants.COMMA) + 1, customerAddress.lastIndexOf(Constants.HYPHEN) - 1).trim();
        addressDto.setCity(city);
        Map<String, List<Location>> locationDetails = findLocationDetails(city);
        if (Objects.nonNull(locationDetails.get(city))) {
            addressDto.setTier(locationDetails.get(city).get(0).getTier());
            addressDto.setLatitude(locationDetails.get(city).get(0).getLatitude());
            addressDto.setLongitude(locationDetails.get(city).get(0).getLongitude());
        }
        addressDto.setCreatedBy(address.getUserId());
        addressDto.setUpdatedBy(address.getUserId());
    }

    /**
     * Returns details of a user.
     *
     * @return Object - Details of user.
     */
    public UserDataDto getUserDetails() {
        return findById(CacheUtil.getUserId());
    }

    /**
     * Returns details of a user by mobile number.
     *
     * @param searchValue - Mobile number of a user.
     * @return Object - Details of user.
     */
    public UserDto getUserDetails(String searchValue, String type) {
        Specification<User> baseSpecification;
        if (type.equals(PARTNER)) {
            baseSpecification = userSpecifications.findByEmail(searchValue);
        } else if (type.equals(CUSTOMER)) {
            baseSpecification = userSpecifications.findByMobileNumber(searchValue);
        } else {
            baseSpecification = userSpecifications.findByBatchUser();
        }
        var userDto = findOne(baseSpecification);
        return getUserDto(userDto, Boolean.FALSE, 0L);
    }

    /**
     * Check whether the user already exists in database during registration.
     *
     * @param searchValue - Mobile number or email of user.
     * @return Boolean - True (or) false.
     */
    public Object checkUserExists(String searchValue) {
        Optional<User> user = userExists(searchValue, "customer");
        if (user.isPresent()) {
            throw new UserExistException(ErrorCode.USER_ALREADY_EXISTS, responseMessage.getErrorMessage(ErrorCode.USER_ALREADY_EXISTS));
        }
        return Boolean.FALSE;
    }

    public GenericResponseDto updateUserOnboardStatus() {
        var userDataDto = findById(CacheUtil.getUserId());
        userDataDto.setOnboardingStatus(OnboardStatus.ACCOUNT_LINKED);
        patch(userDataDto);
        var genericResponseDto = new GenericResponseDto();
        genericResponseDto.setStatus(Constants.SUCCESS);
        return genericResponseDto;
    }

    /**
     * Returns the profile details of the current logged user.
     *
     * @return userProfileDto - Profile details of a user.
     */
    public UserProfileDto getProfile() {
        var userDataDto = findById(CacheUtil.getUserId());
        var userProfileDto = new UserProfileDto();
        var userName = CommonUtil.constructString(userDataDto.getFirstName(), userDataDto.getMiddleName(), userDataDto.getLastName());
        userProfileDto.setUserName(userName.trim());
        if (Objects.nonNull(userDataDto.getImage())) {
            String base64Image = awsStorageService.convertS3UriToBase64(userDataDto.getImage());
            userProfileDto.setUserPic(base64Image);
        } else {
            userProfileDto.setUserPic(null);
        }
        return userProfileDto;
    }

    /**
     * Returns the profile details of the current logged user.
     *
     * @return userProfileDetailDto - Profile details of a user.
     */
    public UserProfileDetailDto getProfileDetail() {
        var userDataDto = findById(CacheUtil.getUserId());
        var userName = CommonUtil.constructString(userDataDto.getFirstName(), userDataDto.getMiddleName(), userDataDto.getLastName());
        var userProfileDetailDto = new UserProfileDetailDto();
        userProfileDetailDto.setUserName(userName.trim());
        userProfileDetailDto.setSavingPreference(SavingPreference.valueOf(userDataDto.getSavingPreference()).name());
        if (Objects.nonNull(userDataDto.getImage())) {
            String base64Image = awsStorageService.convertS3UriToBase64(userDataDto.getImage());
            userProfileDetailDto.setUserPic(base64Image);
        } else {
            userProfileDetailDto.setUserPic(null);
        }
        return userProfileDetailDto;
    }

    /**
     * Updates the profile details of a user.
     *
     * @return userProfileDetailDto - Profile details of a user.
     */
    public UserProfileDetailDto updateProfileDetail(UserProfileDetailDto userProfileDetailDto) {
        var userDataDto = findById(CacheUtil.getUserId());
        if (Objects.nonNull(userProfileDetailDto.getUserPic())) {
            String uniqueFileName = getUniqueFileName(userProfileDetailDto);
            userDataDto.setImage(uniqueFileName);
            awsStorageService.saveFileIntoS3(awsStorageConfig.getImagesBucket(), uniqueFileName, Base64.decodeBase64((userProfileDetailDto.getUserPic().substring(userProfileDetailDto.getUserPic().indexOf(Constants.COMMA) + 1)).getBytes()), CacheUtil.getUserId(), PROFILE_FOLDER);
        } else {
            userDataDto.setImage(null);
        }
        userDataDto.setSavingPreference(SavingPreference.valueOf(userProfileDetailDto.getSavingPreference()).code());
        patch(userDataDto);
        return getProfileDetail();
    }

    /**
     * Creates a unique file name for a user.
     *
     * @param userProfileDetailDto - Details of the Profile received from client.
     * @return String - The unique file name.
     */
    private String getUniqueFileName(UserProfileDetailDto userProfileDetailDto) {
        var fileExtension = userProfileDetailDto.getUserPic().substring(userProfileDetailDto.getUserPic().indexOf(Constants.FORWARD_SLASH) + 1, userProfileDetailDto.getUserPic().indexOf(Constants.SEMI_COLON));
        if (fileExtension.equals("svg+xml")) {
            return CacheUtil.getUserId() + ".svg";
        }
        return CacheUtil.getUserId() + Constants.DOT + fileExtension;
    }

    /**
     * Registers the partner in user table.
     *
     * @param partnerDto - Details of partner.
     * @return Boolean - True (or) false.
     */
    public Boolean registerPartner(PartnerDto partnerDto) {
        Optional<User> user = userExists(partnerDto.getEmail(), PARTNER);
        if (user.isPresent()) {
            throw new UserExistException(ErrorCode.USER_ALREADY_EXISTS, responseMessage.getErrorMessage(ErrorCode.USER_ALREADY_EXISTS));
        }
        var userDataDto = new UserDataDto();
        userDataDto.setEmail(partnerDto.getEmail());
        userDataDto.setFirstName(partnerDto.getName());
        var password = CommonUtil.generateRandomPassword();
        var encodedPassword = CommonUtil.getEncodedPassword(password);
        userDataDto.setPassword(encodedPassword);
        List<String> oldPasswords = new ArrayList<>();
        oldPasswords.add(encodedPassword);
        userDataDto.setOldPassword(oldPasswords);
        userDataDto.setOnboardingStatus(OnboardStatus.REGISTRATION_COMPLETED);
        userDataDto.setUserType(PARTNER);
        userDataDto.setPartnerLoggedIn(Boolean.TRUE);
        userDataDto.setMobile(partnerDto.getMobile());
        userDataDto.setTimeZone("Asia/Kolkata");
        userDataDto.setBatchUser(Boolean.FALSE);
        userDataDto.setFailureAttempts(0);
        userDataDto.setAccountLocked(Boolean.FALSE);
        userDataDto.setLockTime(DateUtil.currentDateTime());
        userDataDto.setPasswordChangedTime(DateUtil.currentDateTime());
        var userDto = add(userDataDto);
        saveUserRole(userDto, Boolean.FALSE);
        emailService.sendEmail("Welcome to Fego", "Hi " + partnerDto.getName() + System.lineSeparator() + "Congrats on registering with Fego." + System.lineSeparator() + "Your default password is - " + password, partnerDto.getEmail(), null);
        return Boolean.TRUE;
    }

    /**
     * Updates the existing password with the new password of a user.
     *
     * @param resetPasswordDto - Details of partner.
     * @return Boolean - True (or) false.
     */
    public Boolean changePassword(ResetPasswordDto resetPasswordDto) {
        var userDetailsDto = SecurityCommon.getUserDetails();
        if (!userDetailsDto.getEmail().equals(resetPasswordDto.getEmail())) {
            throw new FegoAuthenticationException(ErrorCode.UNAUTHORIZED_USER,
                    responseMessage.getErrorMessage(ErrorCode.UNAUTHORIZED_USER));
        }
        Specification<User> userSpecification = userSpecifications.findByEmail(resetPasswordDto.getEmail());
        Optional<UserDataDto> userDataDto = findOneOrReturnEmpty(userSpecification);
        if (userDataDto.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND, CANNOT_FIND_THE_USER);
        }
        if (resetPasswordDto.getNewPassword().equals(resetPasswordDto.getOldPassword())) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, PASSWORD_SAME_AS_OLD_PASSWORD_MESSAGE);
        }
        if (resetPasswordDto.getNewPassword().equals(resetPasswordDto.getEmail())) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, PASSWORD_SAME_AS_USERNAME_MESSAGE);
        }
        if (CommonUtil.isValidPassword(resetPasswordDto.getNewPassword()).equals(Boolean.FALSE)) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, PASSWORD_POLICY_REQUIREMENT_MESSAGE);
        }
        var userDto = userDataDto.get();
        if (CommonUtil.isPasswordEqual(resetPasswordDto.getOldPassword(), userDto.getPassword()).equals(Boolean.FALSE)) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, OLD_PASSWORD_INCORRECT_MESSAGE);
        }
        validateNewPassword(userDto, resetPasswordDto.getNewPassword());
        if (CommonUtil.isPasswordEqual(resetPasswordDto.getOldPassword(), userDto.getPassword()).equals(Boolean.TRUE)) {
            userDto.setPassword(CommonUtil.getEncodedPassword(resetPasswordDto.getNewPassword()));
            userDto.setPartnerLoggedIn(Boolean.FALSE);
            userDto.setPasswordChangedTime(DateUtil.currentDateTime());
            patch(userDto);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    /**
     * Validates the new password by checking with the previous set of used passwords.
     *
     * @param userDto     - Details of partner.
     * @param newPassword - New password entered by partner.
     */
    private void validateNewPassword(UserDataDto userDto, String newPassword) {
        if (userDto.getOldPassword().stream().map(mapper -> CommonUtil.isPasswordEqual(newPassword, mapper)).anyMatch(predicate -> predicate.equals(Boolean.TRUE))) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, PASSWORD_SAME_AS_PREVIOUS_FOUR_PASSWORD_MESSAGE);
        } else {
            List<String> oldPasswords = new ArrayList<>(userDto.getOldPassword());
            if (userDto.getOldPassword().size() >= 4) {
                oldPasswords.remove(0);
            }
            oldPasswords.add(CommonUtil.getEncodedPassword(newPassword));
            userDto.setOldPassword(oldPasswords);
        }
    }

    /**
     * Generates OTP for forget password request.
     *
     * @param email - Email id of a user.
     * @return Boolean - True (or) false.
     */
    public Boolean generateOTPForUser(String email) {
        Specification<User> userSpecification = userSpecifications.findByEmail(email);
        Optional<UserDataDto> userDataDto = findOneOrReturnEmpty(userSpecification);
        if (userDataDto.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND, CANNOT_FIND_THE_USER);
        }
        var userDto = userDataDto.get();
        userDto.setForgetPasswordKey(CommonUtil.generateOtp());
        userDto.setVerificationTokenSentTime(DateUtil.currentDateTime());
        patch(userDto);
        emailService.sendEmail("Fego - Password reset OTP", "Your OTP is - " + userDto.getForgetPasswordKey(), userDto.getEmail(), null);
        return Boolean.TRUE;
    }

    /**
     * Verifies the OTP for forget password request.
     *
     * @param email - Email id of a user.
     * @param otp   - OTP sent to the user.
     * @return Boolean - True (or) false.
     */
    public Boolean verifyOTPFromUser(String email, String otp) {
        Specification<User> userSpecification = userSpecifications.findByEmail(email);
        Optional<UserDataDto> userDataDto = findOneOrReturnEmpty(userSpecification);
        if (userDataDto.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND, CANNOT_FIND_THE_USER);
        }
        var userDto = userDataDto.get();
        if (!otp.equals(userDto.getForgetPasswordKey())) {
            throw new BadRequestException(ErrorCode.INVALID_OTP, responseMessage.getErrorMessage(ErrorCode.INVALID_OTP));
        }
        if (DateUtil.minutesBetweenTwoTime(userDto.getVerificationTokenSentTime(), DateUtil.currentDateTime()) > 3) {
            throw new BadRequestException(ErrorCode.INVALID_OTP, responseMessage.getErrorMessage(ErrorCode.INVALID_OTP));
        }
        return Boolean.TRUE;
    }

    /**
     * Updates the existing password with the new password of a user.
     *
     * @param email    - Email of a user.
     * @param password - New password.
     * @return Boolean - True (or) false.
     */
    public Boolean updateNewPasswordAfterOTPVerification(String email, String password) {
        Specification<User> userSpecification = userSpecifications.findByEmail(email);
        Optional<UserDataDto> userDataDto = findOneOrReturnEmpty(userSpecification);
        if (userDataDto.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND, CANNOT_FIND_THE_USER);
        }
        if (CommonUtil.isPasswordEqual(password, userDataDto.get().getPassword()).equals(Boolean.TRUE)) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, PASSWORD_SAME_AS_OLD_PASSWORD_MESSAGE);
        }
        if (password.equals(email)) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, PASSWORD_SAME_AS_USERNAME_MESSAGE);
        }
        if (CommonUtil.isValidPassword(password).equals(Boolean.FALSE)) {
            throw new InvalidDataException(ErrorCode.INVALID_PASSWORD, PASSWORD_POLICY_REQUIREMENT_MESSAGE);
        }
        var userDto = userDataDto.get();
        validateNewPassword(userDto, password);
        if (Objects.nonNull(userDto.getForgetPasswordKey())) {
            userDto.setPassword(CommonUtil.getEncodedPassword(password));
            userDto.setAccountLocked(Boolean.FALSE);
            userDto.setFailureAttempts(0);
            userDto.setPartnerLoggedIn(Boolean.FALSE);
            userDto.setForgetPasswordKey(null);
            userDto.setPasswordChangedTime(DateUtil.currentDateTime());
            patch(userDto);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    /**
     * Generates an authentication token for partner login
     *
     * @param partnerLoginRequestDto - Details of partner.
     * @return userDto - Details of user.
     */
    public Object verifyPartnerLogin(PartnerLoginRequestDto partnerLoginRequestDto) {
        Specification<User> userSpecification = userSpecifications.findByEmail(partnerLoginRequestDto.getEmail());
        Optional<UserDataDto> userDataDto = findOneOrReturnEmpty(userSpecification);
        if (userDataDto.isEmpty()) {
            throw new RecordNotFoundException(ErrorCode.RECORD_NOT_FOUND, CANNOT_FIND_THE_USER);
        }
        var userDto = userDataDto.get();
        if (userDto.getAccountLocked().equals(Boolean.TRUE)) {
            if (DateUtil.currentDateTime().isAfter(DateUtil.plusDays(userDto.getLockTime(), 1))) {
                userDto.setFailureAttempts(0);
                userDto.setAccountLocked(Boolean.FALSE);
                userDto.setLockTime(DateUtil.currentDateTime());
                patch(userDto);
            } else {
                throw new FegoAuthenticationException(ErrorCode.INVALID_PASSWORD, ACCOUNT_LOCKED_MESSAGE);
            }
        }
        if (CommonUtil.isPasswordEqual(partnerLoginRequestDto.getPassword(), userDto.getPassword()).equals(Boolean.FALSE)) {
            if (userDto.getFailureAttempts() >= 3) {
                userDto.setAccountLocked(Boolean.TRUE);
                userDto.setLockTime(DateUtil.currentDateTime());
                patch(userDto);
                throw new FegoAuthenticationException(ErrorCode.INVALID_PASSWORD, ACCOUNT_LOCKED_MESSAGE);
            }
            userDto.setFailureAttempts(userDto.getFailureAttempts() + 1);
            patch(userDto);
            throw new FegoAuthenticationException(ErrorCode.INVALID_PASSWORD, LOGIN_FAILED_MESSAGE);
        }
        userDto.setFailureAttempts(0);
        userDto.setAccountLocked(Boolean.FALSE);
        patch(userDto);
        var hashKey = userDto.getId() + Constants.UNDERSCORE + userDto.getEmail();
        var isAlreadyLoggedIn = cacheService.delete(hashKey);
        cacheService.save(hashKey, IS_ALREADY_LOGGED_IN, isAlreadyLoggedIn);
        cacheService.save(hashKey, PARTNER_EMAIL, userDto.getEmail());
        if (userDto.getPartnerLoggedIn().equals(Boolean.FALSE)) {
            cacheService.save(hashKey, Constants.TIME_ZONE, userDto.getTimeZone());
        }
        var tenantDto = tenantService.findByTenantName(TenantContext.getTenantId());
        cacheService.save(hashKey, Constants.IS_DATA_CATEGORIZATION_SUBSCRIBED, tenantDto.getDataCategorizationSubscribed());
        return getUserDto(userDto, DateUtil.currentDateTime().isAfter(DateUtil.plusDays(userDto.getPasswordChangedTime(), 90)), 0L);
    }

    /**
     * Updates the user session.
     *
     * @param sessionId - Session Id of user.
     * @return Boolean - True (or) False.
     */
    public Boolean updateUserSession(Long sessionId) {
        var result = Boolean.FALSE;
        Specification<UserSession> userSessionSpecification = userSessionIdSpecifications.findById(sessionId);
        Optional<UserSessionDto> userSessionDto = userSessionService.findOneOrReturnEmpty(userSessionSpecification);
        if (userSessionDto.isPresent()) {
            var userSession = userSessionDto.get();
            Specification<SessionAudit> specification = sessionAuditSpecifications.findByUserId(userSession.getUserId());
            List<SessionAudit> sessionAudit = sessionAuditService.findAllModels(specification);
            Optional<LocalDateTime> lastAccessedTime = sessionAudit.stream().sorted(Comparator.comparing(SessionAudit::getCreatedAt).reversed()).map(SessionAudit::getCreatedAt).findFirst();
            userSession.setEndTime(lastAccessedTime.orElseGet(DateUtil::currentDateTime));
            userSession.setDuration(DateUtil.secondsBetweenTwoDates(userSession.getStartTime(), userSession.getEndTime()));
            userSessionService.patch(userSession);
            result = Boolean.TRUE;
        }
        return result;
    }

    /**
     * Account Aggregator enable and disable.
     *
     * @return Boolean - True (or) False.
     */
    public Boolean subscribeAccountAggregator() {
        var tenantDto = tenantService.findByTenantName(TenantContext.getTenantId());
        if (tenantDto.getAccountAggregatorSubscribed().equals(Boolean.TRUE)) {
            tenantDto.setAccountAggregatorSubscribed(Boolean.FALSE);
            tenantService.patch(tenantDto);
            sendAccountAggregatorEmail(false, tenantDto.getDescription());
        } else {
            tenantDto.setAccountAggregatorSubscribed(Boolean.TRUE);
            tenantService.patch(tenantDto);
            sendAccountAggregatorEmail(true, tenantDto.getDescription());
        }
        return true;
    }

    /**
     * Sends an email to the partner when AA is enabled (or) disabled.
     *
     * @param subscribeFlag - Flag of AA subscription.
     * @param tenantName    - Tenant Name.
     */
    private void sendAccountAggregatorEmail(boolean subscribeFlag, String tenantName) {
        var text = subscribeFlag ? "enabled" : "disabled";
        emailService.sendEmail(CommonUtil.getPlaceHolder("Fego[{0}] - Account Aggregator has been {1}", tenantName, text), CommonUtil.getPlaceHolder("Account Aggregator for the Tenant [{0}] has been {1} by {2}", tenantName, text, CacheUtil.getPartnerEmail()), SUPPORT_EMAIL, null);
    }

    /**
     * Add an entry to Session Audit table with the incoming request.
     *
     * @param sessionAuditDto - Session Audit details
     * @return Boolean - True (or) False.
     */
    public Boolean addAuditRecord(SessionAuditDto sessionAuditDto) {
        sessionAuditService.add(sessionAuditDto);
        return Boolean.TRUE;
    }
}
