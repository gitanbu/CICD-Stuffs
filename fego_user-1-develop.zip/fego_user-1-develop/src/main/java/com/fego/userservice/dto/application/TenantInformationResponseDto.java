package com.fego.userservice.dto.application;

/**
 * <p>
 * Holds the information of the Tenant.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on July 01, 2021
 */
public class TenantInformationResponseDto {
    private TenantDto tenantDto;
    private String categorizationPercentage;

    public TenantDto getTenantDto() {
        return tenantDto;
    }

    public void setTenantDto(TenantDto tenantDto) {
        this.tenantDto = tenantDto;
    }

    public String getCategorizationPercentage() {
        return categorizationPercentage;
    }

    public void setCategorizationPercentage(String categorizationPercentage) {
        this.categorizationPercentage = categorizationPercentage;
    }
}
