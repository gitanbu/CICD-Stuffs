package com.fego.userservice.entity;

import com.fego.userservice.common.base.BaseModel;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * <p>
 * Holds details of Tenant
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on April 18, 2021.
 */
@Entity
@Table
public class Tenant extends BaseModel {
    private String name;
    private String description;
    private String address;
    private String type;
    private String accountAggregator;
    private Boolean isOnboardingSubscribed;
    private Boolean isAccountAggregatorSubscribed;
    private Boolean isDataCategorizationSubscribed;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAccountAggregator() {
        return accountAggregator;
    }

    public void setAccountAggregator(String accountAggregator) {
        this.accountAggregator = accountAggregator;
    }

    public Boolean getOnboardingSubscribed() {
        return isOnboardingSubscribed;
    }

    public void setOnboardingSubscribed(Boolean onboardingSubscribed) {
        isOnboardingSubscribed = onboardingSubscribed;
    }

    public Boolean getDataCategorizationSubscribed() {
        return isDataCategorizationSubscribed;
    }

    public void setDataCategorizationSubscribed(Boolean dataCategorizationSubscribed) {
        isDataCategorizationSubscribed = dataCategorizationSubscribed;
    }

    public Boolean getAccountAggregatorSubscribed() {
        return isAccountAggregatorSubscribed;
    }

    public void setAccountAggregatorSubscribed(Boolean accountAggregatorSubscribed) {
        isAccountAggregatorSubscribed = accountAggregatorSubscribed;
    }
}