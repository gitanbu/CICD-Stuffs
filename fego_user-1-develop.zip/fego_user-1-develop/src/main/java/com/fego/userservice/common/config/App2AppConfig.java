package com.fego.userservice.common.config;

import com.fego.userservice.common.Constants;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * Fetches value from Application-url file.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "application")
@PropertySource(value = "classpath:application-url.yml", factory = YamlPropertySourceFactory.class)
public class App2AppConfig {
    private Map<String, String> integration = new HashMap<>();
    private Map<String, String> transaction = new HashMap<>();

    public Map<String, String> getIntegration() {
        return integration;
    }

    public void setIntegration(Map<String, String> integration) {
        this.integration = integration;
    }

    public Map<String, String> getTransaction() {
        return transaction;
    }

    public void setTransaction(Map<String, String> transaction) {
        this.transaction = transaction;
    }

    public String getIntegrationBaseUrl() {
        return this.getIntegration().get(Constants.BASE_URL);
    }

    public String getTransactionBaseUrl() {
        return this.getTransaction().get(Constants.BASE_URL);
    }
}