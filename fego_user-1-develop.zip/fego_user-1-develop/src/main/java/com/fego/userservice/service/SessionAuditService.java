package com.fego.userservice.service;

import com.fego.foundation.common.utils.DateUtil;
import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.common.base.BaseService;
import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.dto.application.SessionAuditDto;
import com.fego.userservice.dto.userengagement.SessionAuditDetailDto;
import com.fego.userservice.entity.SessionAudit;
import com.fego.userservice.repository.SessionAuditRepository;
import com.fego.userservice.task.SessionAuditTask;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/**
 * <p>
 * CRUD implementation for UserSession.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on July 27, 2021
 */
@Service
public class SessionAuditService extends BaseService<SessionAudit, SessionAuditDto, SessionAuditTask> {


    private final SessionAuditRepository sessionAuditRepository;
    private final List<String> sessionAuditModules = List.of("Goal", "Financial Calendar", "Notification", "Budget", "Expense", "Score");

    public SessionAuditService(BaseMapper<SessionAudit, SessionAuditDto> sessionAuditMapper,
                               IdSpecifications<SessionAudit> sessionAuditIdSpecifications, SessionAuditRepository sessionAuditRepository,
                               BaseTask<SessionAudit> sessionAuditTask) {
        super(sessionAuditRepository, sessionAuditMapper, sessionAuditIdSpecifications, sessionAuditTask);
        this.sessionAuditRepository = sessionAuditRepository;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateAdd(SessionAuditDto sessionAuditDto) {
        sessionAuditDto.setCreatedBy(sessionAuditDto.getUserId());
        sessionAuditDto.setUpdatedBy(sessionAuditDto.getUserId());
    }

    /**
     * Method to return last month data from session audit table
     *
     * @return List<SessionAuditDetailDto> - List contains last two month session audit record
     */
    public List<SessionAuditDetailDto> getSessionAudit() {
        LocalDate currentDate = DateUtil.currentDate();
        LocalDateTime lastMonthEndDate = DateUtil.minusMonthsFromLastDay(currentDate, 1).atTime(LocalTime.MAX);
        LocalDateTime lastMonthStartDate = DateUtil.minusMonthsFromFirstDay(currentDate, 1).atTime(LocalTime.MIN);
        return sessionAuditRepository.getSessionAuditDetails(lastMonthStartDate, lastMonthEndDate, sessionAuditModules);
    }
}