package com.fego.userservice.task;

import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.entity.Tenant;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Performs a task when a CRUD operation on Tenant Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Component
public class TenantTask implements BaseTask<Tenant> {

    @Override
    public void onCreate(Tenant model) {
        // Method which executes after an Tenant object is created.
    }

    @Override
    public void onUpdate(Tenant model) {
        // Method which executes after an Tenant object is updated.
    }

    @Override
    public void onDelete(Tenant model) {
        // Method which executes after an Tenant object is deleted.
    }
}