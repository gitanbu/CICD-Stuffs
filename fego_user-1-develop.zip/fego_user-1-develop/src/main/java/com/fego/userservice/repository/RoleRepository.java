package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.entity.Role;

/**
 * <p>
 * Repository for Role Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
public interface RoleRepository extends BaseRepository<Role> {
}