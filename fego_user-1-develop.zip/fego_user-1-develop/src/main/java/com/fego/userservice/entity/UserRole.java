package com.fego.userservice.entity;

import com.fego.userservice.common.base.BaseModel;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * <p>
 * Join table for User and Role.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 20, 2021.
 */
@Entity
@Table
public class UserRole extends BaseModel {

    private long userId;
    private long roleId;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getRoleId() {
        return roleId;
    }

    public void setRoleId(long roleId) {
        this.roleId = roleId;
    }
}