package com.fego.userservice.service;

import com.fego.foundation.common.utils.DateUtil;
import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.common.base.BaseService;
import com.fego.userservice.common.base.BaseTask;
import com.fego.userservice.common.base.specification.IdSpecifications;
import com.fego.userservice.dto.application.UserSessionDto;
import com.fego.userservice.dto.userengagement.UserSessionDetailDto;
import com.fego.userservice.entity.UserSession;
import com.fego.userservice.repository.UserSessionRepository;
import com.fego.userservice.task.UserSessionTask;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * CRUD implementation for UserSession.
 * </p>
 *
 * @author Created by Arun Balaji Rajasekaran on July 27, 2021
 */
@Service
public class UserSessionService extends BaseService<UserSession, UserSessionDto, UserSessionTask> {

    private final UserSessionRepository sessionRepository;

    public UserSessionService(BaseMapper<UserSession, UserSessionDto> userSessionMapper,
                              IdSpecifications<UserSession> userSessionIdSpecifications, UserSessionRepository userSessionRepository,
                              BaseTask<UserSession> userSessionTask, UserSessionRepository sessionRepository) {
        super(userSessionRepository, userSessionMapper, userSessionIdSpecifications, userSessionTask);
        this.sessionRepository = sessionRepository;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validateAdd(UserSessionDto userSessionDto) {
        userSessionDto.setCreatedBy(userSessionDto.getUserId());
        userSessionDto.setUpdatedBy(userSessionDto.getUserId());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void doPatch(UserSession incomingUserSession, UserSession toUpdateUserSession) {
        if (Objects.nonNull(incomingUserSession.getEndTime())) {
            toUpdateUserSession.setEndTime(incomingUserSession.getEndTime());
        }
        toUpdateUserSession.setDuration(incomingUserSession.getDuration());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void validatePatch(UserSessionDto userSessionDto) {
        userSessionDto.setUpdatedBy(userSessionDto.getUserId());
    }

    /**
     * Method to fetch last month data from user session table
     *
     * @return List<UserSessionDetailDto> - List contains last month user session table values.
     */
    public List<UserSessionDetailDto> getUserSessionDetails() {
        LocalDate currentDate = DateUtil.currentDate();
        LocalDate lastMonthStartDate = DateUtil.minusMonthsFromFirstDay(currentDate, 1);
        LocalDate lastMonthEndDate = DateUtil.minusMonthsFromLastDay(currentDate, 1);
        return sessionRepository.getUserSessionDetails(lastMonthStartDate, lastMonthEndDate);
    }
}