package com.fego.userservice.mapper;

import com.fego.userservice.common.base.BaseMapper;
import com.fego.userservice.dto.application.SessionAuditDto;
import com.fego.userservice.entity.SessionAudit;
import org.springframework.stereotype.Component;

/**
 * <p>
 * Converts SessionAudit DTO to SessionAudit Entity and vice versa.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on April 18, 2021.
 */
@Component
public class SessionAuditMapper implements BaseMapper<SessionAudit, SessionAuditDto> {

    public SessionAuditDto domainToDto(SessionAudit sessionAudit) {
        var sessionAuditDto = new SessionAuditDto();
        sessionAuditDto.setUserId(sessionAudit.getUserId());
        sessionAuditDto.setUri(sessionAudit.getUri());
        sessionAuditDto.setType(sessionAudit.getType());
        sessionAuditDto.setAction(sessionAudit.getAction());
        sessionAuditDto.setModule(sessionAudit.getModule());
        sessionAuditDto.setIpAddress(sessionAudit.getIpAddress());
        sessionAuditDto.setId(sessionAudit.getId());
        sessionAuditDto.setIsDeleted(sessionAudit.isDeleted());
        sessionAuditDto.setCreatedAt(sessionAudit.getCreatedAt());
        sessionAuditDto.setUpdatedAt(sessionAudit.getUpdatedAt());
        sessionAuditDto.setCreatedBy(sessionAudit.getCreatedBy());
        sessionAuditDto.setUpdatedBy(sessionAudit.getUpdatedBy());
        return sessionAuditDto;
    }

    public SessionAudit dtoToDomain(SessionAuditDto sessionAuditDto) {
        var sessionAudit = new SessionAudit();
        sessionAudit.setUserId(sessionAuditDto.getUserId());
        sessionAudit.setUri(sessionAuditDto.getUri());
        sessionAudit.setType(sessionAuditDto.getType());
        sessionAudit.setAction(sessionAuditDto.getAction());
        sessionAudit.setModule(sessionAuditDto.getModule());
        sessionAudit.setIpAddress(sessionAuditDto.getIpAddress());
        sessionAudit.setDeleted(sessionAuditDto.getIsDeleted());
        sessionAudit.setCreatedBy(sessionAuditDto.getCreatedBy());
        sessionAudit.setUpdatedBy(sessionAuditDto.getUpdatedBy());
        return sessionAudit;
    }
}

