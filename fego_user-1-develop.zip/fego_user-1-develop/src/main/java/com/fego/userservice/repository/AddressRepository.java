package com.fego.userservice.repository;

import com.fego.userservice.common.base.BaseRepository;
import com.fego.userservice.dto.application.AddressDetailsDto;
import com.fego.userservice.entity.Address;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 * Repository for Address Entity.
 * </p>
 *
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@Repository
public interface AddressRepository extends BaseRepository<Address> {
    @Query(value = "select NEW com.fego.userservice.dto.application.AddressDetailsDto (u.userId, u.streetOne, u.city, u.tier, u.latitude, u.longitude, u.isRecent) FROM Address u where u.isDeleted=false")
    List<AddressDetailsDto> getUserAddressDetails();
}
