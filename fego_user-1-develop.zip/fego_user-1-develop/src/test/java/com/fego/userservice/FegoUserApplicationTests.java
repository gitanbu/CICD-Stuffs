package com.fego.userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author Arun Balaji Rajasekaran created on March 9, 2021.
 */
@SpringBootTest
class FegoUserApplicationTests {

    @Test
    void contextLoads() {
    }
}