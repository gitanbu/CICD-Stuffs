package com.fego.userservice.service;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AddressServiceTest {
}
