## Fego User Service

A Backend Application which acts as an Interface between Integration, Transaction and UI.

## Project setup

In the project directory, you can run:

```
mvn clean install
```

then

### Starting the service

```
Run the main class
